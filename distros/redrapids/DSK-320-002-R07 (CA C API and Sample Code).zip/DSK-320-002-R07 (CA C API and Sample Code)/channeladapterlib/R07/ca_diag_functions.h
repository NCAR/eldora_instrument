void ca_Diag_PrintStatusReg(UINT32 StatusReg);
void ca_Diag_ADCFifoTargetWriteToDisk(s_ChannelAdapter *pCA, UINT32 FIFOLowAdr, UINT32 Size, 
		char * Mode, char * chFname);
		
