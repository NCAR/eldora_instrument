/*
 * synth_interface.h - Control interface for the CTI BBS-1301
 * synthesizer through the Measurement Computing PCI-DIO48H digital
 * I/O card.
 *
 * This is really a three wire interface with one additional status
 * line.
 *
 * Copyright (c) 2008 Gordon Farquharson <gordonf@ucar.edu>
 *
 * This file is released under the GPLv2
 *
 */

#ifndef _SYNTH_INTERFACE_H_
#define _SYNTH_INTERFACE_H_

#include <comedilib.h>

struct interface_line {
	unsigned int subdevice;
	unsigned int channel;
	unsigned int direction;
};

struct synth_interface {

	comedi_t *device;

	struct interface_line clock;
	struct interface_line data;
	struct interface_line enable;
	struct interface_line alarm;
};

int synth_interface_init(struct synth_interface *, comedi_t *);

int synth_interface_write_data(struct synth_interface *, 
			       unsigned int, unsigned int);
int synth_interface_read_alarm(struct synth_interface *, unsigned int *);

#endif				/* _SYNTH_INTERFACE_H_ */
