#include <stdlib.h>
#include <getopt.h>

#include <comedilib.h>

#include "cmdline.h"

int parse_options(struct parsed_options *options, int argc, char *argv[])
{
	int c;

	while (-1 != (c = getopt(argc, argv, "f:d:s:c:h"))) {
		switch (c) {
		case 'f':
			options->device_name = optarg;
			break;
		case 'd':
			options->filename = optarg;
			break;
		case 's':
			options->subdevice = strtoul(optarg, NULL, 0);
			break;
		case 'c':
			options->channel = strtoul(optarg, NULL, 0);
			break;
		case 'h':
			show_options();
			exit(0);
		default:
			printf("Unrecognized option\n");
			show_options();
			exit(-1);
		}
	}
	if (optind < argc) {
		/* data value */
		/* options->value = strtod(argv[optind++], NULL); */
		printf("Too many arguments\n");
		show_options();
		exit(-1);
	}

	return argc;
}

void show_options()
{
	printf("Usage:\n");
	printf("   -f <file>     use configuration file <file> (default: synth.conf)\n");
	printf("   -d <file>     use device name <file> (default: /dev/comedi0)\n");
	printf("   -s <subd>     use subdevice <subd> (default: 0)\n");
	printf("   -c <chan>     use channel <chan> (default: 0)\n");
	printf("   -h            display this list of command line options\n");
}
