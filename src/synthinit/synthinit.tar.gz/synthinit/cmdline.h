#ifndef _CMDLINE_H
#define _CMDLINE_H

struct parsed_options {
	char *filename;
	char *device_name;
	int subdevice;
	int channel;
};

int parse_options(struct parsed_options *options, int argc, char *argv[]);
void show_options();

#endif
