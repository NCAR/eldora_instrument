/*
 * synth_device.h - Definition for a three-wire interface synthesizer.
 *
 * Currently this module only supports integer frequencies and step
 * sizes in MHz.
 *
 */

#ifndef _SYNTH_DEVICE_H_
#define _SYNTH_DEVICE_H_

#include <comedilib.h>

#include "synth_interface.h"

struct synth_device;

struct synth_device {
	unsigned int channel_min;    /* Minimum channel number */
	unsigned int channel_max;    /* Maximum channel number */

	unsigned int freq_min;       /* Minimum frequency
				      * synthesizable (MHz) */
	unsigned int freq_max;       /* Maximum frequency
				      * synthesizable (MHz) */
	unsigned int step_size;	     /* Smallest frequency step
				      * between synthesized
				      * frequencies (MHz) */

	unsigned int frequency;      /* Current frequency */

	struct synth_interface interface;

	unsigned int data_length;    /* Length of synthesizer
				      * command bit string */

	int (*calc_data_bitfield)(struct synth_device *, 
				  unsigned int, 
				  unsigned int *);
};

int synth_device_init(struct synth_device *, comedi_t *);

int synth_device_set_frequency(struct synth_device *);
int synth_device_get_status(struct synth_device *, unsigned int *);

/* Specific synthesizer model functions */

int bbs1301_calc_data_bitfield(struct synth_device *, unsigned int, 
			       unsigned int *);

#endif				/* _SYNTH_DEVICE_H_ */
