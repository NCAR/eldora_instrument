#include <unistd.h>
#include <string.h>
#include <math.h>

#include <comedilib.h>

#include "synth_interface.h"

int synth_interface_init(struct synth_interface *i, comedi_t *device)
{
	i->device = device;

	/* Configure direction of DIO lines */

	if (comedi_dio_config(i->device, i->clock.subdevice,
			      i->clock.channel, i->clock.direction) == -1)
		return -1;
	if (comedi_dio_config(i->device, i->data.subdevice,
			      i->data.channel, i->data.direction) == -1)
		return -1;
	if (comedi_dio_config(i->device, i->enable.subdevice,
			      i->enable.channel, i->enable.direction) == -1)
		return -1;
	if (comedi_dio_config(i->device, i->alarm.subdevice,
			      i->alarm.channel, i->alarm.direction) == -1)
		return -1;

	/* Initialize DIO lines to default value */

	if (comedi_dio_write(i->device, i->clock.subdevice,
			     i->clock.channel, 0) == -1) return -1;
	if (comedi_dio_write(i->device, i->enable.subdevice,
			     i->enable.channel, 1) == -1) return -1;

	return 0;
}

int synth_interface_write_data(struct synth_interface *i, 
			       unsigned int bitfield, 
			       unsigned int length)
{
	unsigned int bit;

	/* The clock lines start in the low state. Enable starts in
	 * the high state. */

	if (comedi_dio_write(i->device, i->enable.subdevice,
			     i->enable.channel, 0) == -1) return -1;

	usleep(100);

	for (int count=0; count < length; count++) {

		bit = (bitfield & (0x0200 >> count) ? 1 : 0);

		if (comedi_dio_write(i->device, i->data.subdevice,
				     i->data.channel, bit) == -1) return -1;
		usleep(0);

		if (comedi_dio_write(i->device, i->clock.subdevice,
				     i->clock.channel, 1) == -1) return -1;
		usleep(0);
		if (comedi_dio_write(i->device, i->clock.subdevice,
				     i->clock.channel, 0) == -1) return -1;

		usleep(0);
	}

	usleep(0);

	if (comedi_dio_write(i->device, i->enable.subdevice,
			     i->enable.channel, 1) == -1) return -1;

	return 0;
}

int synth_interface_read_alarm(struct synth_interface *i, unsigned int *bit)
{
	return comedi_dio_read(i->device, i->alarm.subdevice,
			       i->alarm.channel, bit);
}
