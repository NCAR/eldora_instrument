#include <string.h>

#include <comedilib.h>

#include "synth_device.h"
#include "synth_interface.h"

int synth_device_init(struct synth_device *s, comedi_t *device)
{
	return synth_interface_init(&s->interface, device);
}

int synth_device_set_frequency(struct synth_device *s)
{
	unsigned int bitfield;
	
	if ((*(s->calc_data_bitfield))(s, s->frequency, &bitfield) == -1) 
		return -1;
	
	return synth_interface_write_data(&s->interface, bitfield, 
					  s->data_length);
}

int synth_device_get_status(struct synth_device *s, unsigned int *bit)
{
	return synth_interface_read_alarm(&s->interface, bit);
}

/* Function to calcuclate the data bits for the CTI BBS-1301
 * three-wire interface syntheszier */

int bbs1301_calc_data_bitfield(struct synth_device *s,
			       unsigned int frequency, unsigned int *bitfield)
{
	unsigned int channel_number;
	unsigned int result;
	
	if ((frequency < s->freq_min) || (frequency > s->freq_max))
		return -1;
	
	channel_number = frequency - s->freq_min;
	result = (channel_number & ((1 << s->data_length) - 1));
	memcpy(bitfield, &result, sizeof(unsigned int));
	
	return 0;
}
