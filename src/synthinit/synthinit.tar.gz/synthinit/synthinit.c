#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include <comedilib.h>

#include "cmdline.h"

#include "synth_device.h"

int subdev = 0;			/* change this to your input subdevice */
int chan = 0;			/* change this to your channel */
int range = 0;			/* more on this later */
int aref = AREF_GROUND;		/* more on this later */

static char *const default_configuration_filename = "synth.conf";
static char *const default_device_name = "/dev/comedi0";

void init_parsed_options(struct parsed_options *);
int read_freq_config_file(char *, struct synth_device *, 
			  unsigned int, unsigned int);

int main(int argc, char *argv[])
{
	struct parsed_options options;
	comedi_t *dio_device;

	/* FIXME: all of this information should be in a configuration
	 * file. Right now, we only have the frequency to which the
	 * synthesizer will be programmed stored in a configuration
	 * file. */

	const unsigned int upconv_lo_freq = 8060;

	const unsigned int number_of_synthesizers = 6;
	struct synth_device synthesizers[] = {
		{		/* Channel 1 */
			.channel_min        = 0,
			.channel_max        = 500,
			.freq_min           = 1240,
			.freq_max           = 1740,
			.step_size          = 1,
			.frequency          = 1240,
			.interface          = {
				.device = NULL,
				.clock = {
					 .subdevice = 0,
					 .channel = 0,
					 .direction = COMEDI_OUTPUT,
				 },
				.data = {
					 .subdevice = 0,
					 .channel = 6,
					 .direction = COMEDI_OUTPUT,
				 },
				.enable = {
					 .subdevice = 0,
					 .channel = 15,
					 .direction = COMEDI_OUTPUT,
				 },
				.alarm = {
					 .subdevice = 1,
					 .channel = 1,
					 .direction = COMEDI_INPUT,
				 },
			},
			.data_length        = 10,
			.calc_data_bitfield = bbs1301_calc_data_bitfield,
		},
		{		/* Channel 2 */
			.channel_min        = 0,
			.channel_max        = 500,
			.freq_min           = 1240,
			.freq_max           = 1740,
			.step_size          = 1,
			.frequency          = 1240,
			.interface          = {
				.device = NULL,
				.clock = {
					 .subdevice = 0,
					 .channel = 0,
					 .direction = COMEDI_OUTPUT,
				 },
				.data = {
					 .subdevice = 0,
					 .channel = 6,
					 .direction = COMEDI_OUTPUT,
				 },
				.enable = {
					 .subdevice = 0,
					 .channel = 14,
					 .direction = COMEDI_OUTPUT,
				 },
				.alarm = {
					 .subdevice = 1,
					 .channel = 0,
					 .direction = COMEDI_INPUT,
				 },
			},
			.data_length        = 10,
			.calc_data_bitfield = bbs1301_calc_data_bitfield,
		},
		{		/* Channel 3 */
			.channel_min        = 0,
			.channel_max        = 500,
			.freq_min           = 1240,
			.freq_max           = 1740,
			.step_size          = 1,
			.frequency          = 1240,
			.interface          = {
				.device = NULL,
				.clock = {
					 .subdevice = 0,
					 .channel = 0,
					 .direction = COMEDI_OUTPUT,
				 },
				.data = {
					 .subdevice = 0,
					 .channel = 6,
					 .direction = COMEDI_OUTPUT,
				 },
				.enable = {
					 .subdevice = 0,
					 .channel = 13,
					 .direction = COMEDI_OUTPUT,
				 },
				.alarm = {
					 .subdevice = 1,
					 .channel = 15,
					 .direction = COMEDI_INPUT,
				 },
			},
			.data_length        = 10,
			.calc_data_bitfield = bbs1301_calc_data_bitfield,
		},
		{		/* Channel 4 */
			.channel_min        = 0,
			.channel_max        = 500,
			.freq_min           = 1240,
			.freq_max           = 1740,
			.step_size          = 1,
			.frequency          = 1240,
			.interface          = {
				.device = NULL,
				.clock = {
					 .subdevice = 0,
					 .channel = 2,
					 .direction = COMEDI_OUTPUT,
				 },
				.data = {
					 .subdevice = 0,
					 .channel = 4,
					 .direction = COMEDI_OUTPUT,
				 },
				.enable = {
					 .subdevice = 0,
					 .channel = 12,
					 .direction = COMEDI_OUTPUT,
				 },
				.alarm = {
					 .subdevice = 1,
					 .channel = 14,
					 .direction = COMEDI_INPUT,
				 },
			},
			.data_length        = 10,
			.calc_data_bitfield = bbs1301_calc_data_bitfield,
		},
		{		/* Channel 5 */
			.channel_min        = 0,
			.channel_max        = 500,
			.freq_min           = 1240,
			.freq_max           = 1740,
			.step_size          = 1,
			.frequency          = 1240,
			.interface          = {
				.device = NULL,
				.clock = {
					 .subdevice = 0,
					 .channel = 2,
					 .direction = COMEDI_OUTPUT,
				 },
				.data = {
					 .subdevice = 0,
					 .channel = 4,
					 .direction = COMEDI_OUTPUT,
				 },
				.enable = {
					 .subdevice = 0,
					 .channel = 11,
					 .direction = COMEDI_OUTPUT,
				 },
				.alarm = {
					 .subdevice = 1,
					 .channel = 13,
					 .direction = COMEDI_INPUT,
				 },
			},
			.data_length        = 10,
			.calc_data_bitfield = bbs1301_calc_data_bitfield,
		},
		{		/* Channel 6 */
			.channel_min        = 0,
			.channel_max        = 500,
			.freq_min           = 1240,
			.freq_max           = 1740,
			.step_size          = 1,
			.frequency          = 1240,
			.interface          = {
				.device = NULL,
				.clock = {
					 .subdevice = 0,
					 .channel = 2,
					 .direction = COMEDI_OUTPUT,
				 },
				.data = {
					 .subdevice = 0,
					 .channel = 4,
					 .direction = COMEDI_OUTPUT,
				 },
				.enable = {
					 .subdevice = 0,
					 .channel = 10,
					 .direction = COMEDI_OUTPUT,
				 },
				.alarm = {
					 .subdevice = 1,
					 .channel = 12,
					 .direction = COMEDI_INPUT,
				 },
			},
			.data_length        = 10,
			.calc_data_bitfield = bbs1301_calc_data_bitfield,
		},
	};
	unsigned int locked;

	/* Parse command line arguements */

	init_parsed_options(&options);
	parse_options(&options, argc, argv);

	/* Open device and check if it is a digital I/O card */

	dio_device = comedi_open(options.device_name);
	if (!dio_device) {
		comedi_perror(options.device_name);
		exit(-1);
	}

	if (comedi_get_subdevice_type(dio_device, options.subdevice) 
	    != COMEDI_SUBD_DIO) {
		printf("%d is not a digital I/O subdevice\n",
		       options.subdevice);
		exit(-1);
	}

	if (read_freq_config_file(options.filename, synthesizers, 
				  number_of_synthesizers, upconv_lo_freq) != 0)
		exit(-1);

	for (int i = 0; i < number_of_synthesizers; i++) {
		if (synth_device_init(&(synthesizers[i]), dio_device) != 0) {
			printf("Unable to initialize synthesizers/"
			       "digital I/O interface\n");
			exit(-1);
		}

		printf("Setting synthesizer %d to %d MHz "
		       "(transmit frequency is %d MHz) - ", 
		       i+1, synthesizers[i].frequency, 
		       synthesizers[i].frequency + upconv_lo_freq);

		if (synth_device_set_frequency(&synthesizers[i]) != 0) {
			printf("failed to set the frequency\n");
		} else {
			usleep(50000);

			if (synth_device_get_status(&synthesizers[i], &locked) 
			    < 0)
				printf("failed to read synthesizer status\n");
			else if (locked == 1)
				printf("locked\n");
			else
				printf("not locked\n");
		}
	}
	    
	return 0;
}

void init_parsed_options(struct parsed_options *options)
{
	memset(options, 0, sizeof(struct parsed_options));
	options->filename = default_configuration_filename;
	options->device_name = default_device_name;
	options->subdevice = 0;
	options->channel =0;
}

int read_freq_config_file(char *filename, struct synth_device *s, 
			  unsigned int num_synths, unsigned int lo_freq)
{
	FILE *file_stream;
	unsigned int xband_freq;

	if ((file_stream = fopen(filename, "r")) == NULL) {
		perror(filename);
		return -1;
	}

	for (int count = 0; count < num_synths; count++) {
		if (fscanf(file_stream, "%d", &xband_freq) != 1) {
			if (feof(file_stream))
				printf("Less than %d frequencies in"
				       "configuration file\n", num_synths);
			else if (ferror(file_stream))
				printf("File error (make this message more"
				       "informative\n");
		}
		s[count].frequency = xband_freq - lo_freq;
	}
	return 0;
}
