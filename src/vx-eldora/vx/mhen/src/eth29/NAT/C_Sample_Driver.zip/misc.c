/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : misc.c
*
* Description : Board specific functions
*
* Author      : H.Koerte
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
* 951219 hk Initial version for CUSTOMIZE, adapted from original ms360.c							   *
******************************************************************************
******************************************************************************/

#include <natdefs.h>
#include <hwconfig.h>
#include <ms360.h>

#include <customize.h>                       /*CUSTOMIZE here */

#define USE_AUTO_INCREMENT

/*-------------------------------------------------------------------------*/
FUNCTION void mask_irq(irq_mask)
/*-------------------------------------------------------------------------*/
	u_short *irq_mask;
{
	*irq_mask = CUSTOMIZE_IRQ_MASK_REGISTER;
	CUSTOMIZE_IRQ_MASK_REGISTER = CUSTOMIZE_IRQ_MASK;

	return;
}

/*-------------------------------------------------------------------------*/
FUNCTION void enab_irq(irq_mask)
/*-------------------------------------------------------------------------*/
	u_short *irq_mask;
{
	CUSTOMIZE_IRQ_MASK_REGISTER = *irq_mask;

	return;
}

#ifdef MS360
/*-------------------------------------------------------------------------*/
FUNCTION VOID ms360_set_win(mbase,addr)		/* sets window register	   */
						/* to enable access to     */
						/* specified address       */
/*-------------------------------------------------------------------------*/
	register struct ms360 *mbase;		/* module base address     */
	register u_char *addr;			/* relative addr on ms360  */
{
	u_short winoffset;

	mbase->winreg  = (u_long)(MPRAM_BASE | (u_long)addr & (MPRAM_SIZE-1));

}

#ifndef USE_AUTO_INCREMENT
/*-------------------------------------------------------------------------*/
FUNCTION void cpy_from_ms360(mbase,from,to,size)
/*-------------------------------------------------------------------------*/
	register struct ms360 *mbase;		/* module base address     */
	register u_char *from;			/* abs addr in host memory */
	register u_char *to;			/* relative addr on ms360  */
	register u_long size;			/* size to copy            */
{
	register u_long i;
	u_short winoffset, irq_mask;

	/*-----------------------------------------------*/
	/* copying data from MS360 module to host memory */
	/*-----------------------------------------------*/
	mask_irq(&irq_mask);

	ms360_set_win(mbase, from);

	for(i = (u_long)from & 0x7f; size > 0; size--) {
		*to++ = mbase->data[i];
		i++;
		if(i == 0x80) {		/* must increment window */
			i=0;
			from += 0x80;
			ms360_set_win(mbase, from);
		}
	}
	enab_irq(&irq_mask);
}

/*-------------------------------------------------------------------------*/
FUNCTION void cpy_to_ms360(mbase,from,to,size)
/*-------------------------------------------------------------------------*/
	register struct ms360 *mbase;		/* module base address     */
	register u_char *from;			/* abs addr in host memory */
	register u_char *to;			/* relative addr on ms360  */
	register u_long size;			/* size to copy            */
{
	register u_long i;
	u_short winoffset;
	u_short irq_mask;
/*
	CUSTOMIZE_DEBUG_PRINT("copy data to ms360: mbase=0x%x, from=0x%x, to=0x%x, size=0x%x\n",
		mbase,from,to,size);
*/
	/*-----------------------------------------------*/
	/* copying data from host memory to MS360 module */
	/*-----------------------------------------------*/
	mask_irq(&irq_mask);

	ms360_set_win(mbase, to);

	for(i = (u_long)to & 0x7f; size > 0; size--) {
		mbase->data[i] = *from++;
		i++;
		if(i == 0x80) {		/* must increment window */
			i=0;
			to += 0x80;
			ms360_set_win(mbase, to);
		}
	}
	enab_irq(&irq_mask);
}

#else	/* USE_AUTO_INCREMENT */


/*-------------------------------------------------------------------------*/
FUNCTION void cpy_from_ms360(mbase,from,to,size)
/*-------------------------------------------------------------------------*/
	register struct ms360 *mbase;		/* module base address     */
	register u_char *from;			/* abs addr in host memory */
	register u_char *to;			/* relative addr on ms360  */
	register u_long size;			/* size to copy            */
{
	register u_long i;
	u_short winoffset, irq_mask;

/*	CUSTOMIZE_DEBUG_PRINT("copying data from ms360 to host: %0x -> %0x\n",
			from,to);
*/
	/*-----------------------------------------------*/
	/* copying data from MS360 module to host memory */
	/*-----------------------------------------------*/
	mask_irq(&irq_mask);

	ms360_set_win(mbase, from);

	/*
	 * decide whether we can use  word transfer or not
	 */
	if((((u_long)to | (u_long)from) & 0x1) == 0 ||
			(((u_long)to & (u_long)from) & 0x1) == 1) {
/*		CUSTOMIZE_DEBUG_PRINT("cpy_from: using auto increment !\n"); */
		if(((u_long)to & (u_long)from & 0x1) == 1) {
			*to++ = mbase->data[(u_long)from & 0x7f];
			from++;
			size--;
		}
		for(; size > 1; size -= 2) {
			*(u_short*)to = *(u_short*)&mbase->datareg;
			to   += 2;
			from += 2;
		}

	}	 	/* must copy bytes ! */
	if(size > 0) {
		ms360_set_win(mbase, from);
		for(i = (u_long)from & 0x7f; size > 0; size--) {
			*to++ = mbase->data[i];
			i++;
			if(i == 0x80) {		/* must increment window */
				i=0;
				from += 0x80;
				ms360_set_win(mbase, from);
			}
		}
	}

	enab_irq(&irq_mask);
}

/*-------------------------------------------------------------------------*/
FUNCTION void cpy_to_ms360(mbase,from,to,size)
/*-------------------------------------------------------------------------*/
	register struct ms360 *mbase;		/* module base address     */
	register u_char *from;			/* abs addr in host memory */
	register u_char *to;			/* relative addr on ms360  */
	register u_long size;			/* size to copy            */
{
	register u_long i;
	u_short winoffset;
	u_short irq_mask;
/*
	CUSTOMIZE_DEBUG_PRINT("copy data to ms360: mbase=0x%x, from=0x%x, to=0x%x, size=0x%x\n",
		mbase,from,to,size);
*/
	/*-----------------------------------------------*/
	/* copying data from host memory to MS360 module */
	/*-----------------------------------------------*/
	mask_irq(&irq_mask);

	ms360_set_win(mbase, to);

	/*
	 * decide whether we can use  word transfer or not
	 */
	if((((u_long)to | (u_long)from) & 0x1) == 0
			|| (((u_long)to & (u_long)from) & 0x1) == 1) {
/*		CUSTOMIZE_DEBUG_PRINT("cpy_to: using auto increment !\n"); */
		if(((u_long)to & (u_long)from & 0x1) == 1) {
			mbase->data[(u_long)to & 0x7f] = *from++;
			to++;
			size--;
		}
		for(; size > 1; size -= 2) {
			*((u_short*)&mbase->datareg) = *(u_short*)from;
			from += 2;
			to += 2;
		}

	}	 	/* must copy bytes ! */
	if(size > 0) {
		ms360_set_win(mbase, to);
		for(i = (u_long)to & 0x7f; size > 0; size--) {
			mbase->data[i] = *from++;
			i++;
			if(i == 0x80) {		/* must increment window */
				i=0;
				to += 0x80;
				ms360_set_win(mbase, to);
			}
		}
	}
	enab_irq(&irq_mask);
}

#endif /* ! USE_AUTO_INCREMENT */
#endif /* MS360 */
