/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : nif.h
*
* Description : Definition of the Network InterFace (NIF) structure
*
* Author      : H.Laufkoetter
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
* 011012 cg from .../tcpip/h/sys/nif.h:
*           Added new member psock to struct Par_Socket as we do return
*           the address of the socket structure.
*	    Invented new struct Par_Sock_DropData for NIF.
*           added new command SOC_DROPDATA;
* 940815 hk Added support for sendx(), SysReqMem(), SysRetMem()
* 930107 hl Added Multi Protocol Driver definitions
* 920808 hl Added level in L2M_init_p for VLAN module
* 910524 hl Initial version
******************************************************************************
******************************************************************************/

#ifndef __NIF__
#define __NIF__

typedef struct nif_struct {
	struct mbuf	*mget;
	struct mbuf	*mput;
	struct mbuf	*ActH2S;
	struct mbuf	*ActS2H;
	struct mbuf	*pget;
	struct mbuf	*pput;
	struct mbuf	*SndRaw;
	u_long		SndRSz;
	struct mbuf	*RcvRaw;
	u_long		RcvRSz;
} NIF;

/*------------ Multi Protocoll Driver entry points definition --------------*/

typedef struct mpd {
	long 	a6stat,
		(*L2_Init)(),
		(*L2_Stop)(),
		(*L2_Send)(),
		(*L2_Send_fb)(),
		(*L2_Putnet)(),
		(*L2_Receive)(),
		(*L2_AttProto)(),
		(*L2_AttPort)(),
		(*L2_AddType)(),
		(*L2_AddRDispID)(),
		(*L2_Detach)(),
		(*L2_SetDebug)(),
		(*get_boardID)(),
		(*m_cat)(),
		(*m_copy)(),
		(*m_copydata)(),
		(*m_pullup)(),
		(*m_adj)(),
		(*m_get)(),
		(*m_getclr)(),
		(*m_clget)(),
		(*m_free)(),
		(*m_freem)(),
		(*m_getpag)(),
		(*m_putpag)(),
		(*get_log_boardID)(),
		(*m_clfree)();		/* hk 23.12.93 wasn't here before */
	} MPMOD;

#ifdef MP
#ifndef USE_FUNCTION_LABELS

#define L2_Init(p1) 		callex(mpd->L2_Init,mpd->a6stat,p1)
#define L2_Stop()		callex(mpd->L2_Stop,mpd->a6stat)
#define L2_AttProto(p1,p2,p3,p4,p5) \
 				callex(mpd->L2_AttProto,mpd->a6stat,p1,p2,p3,p4,p5)
#define L2_AttPort(p1,p2,p3,p4,p5) \
 				callex(mpd->L2_AttPort,mpd->a6stat,p1,p2,p3,p4,p5)
#define L2_AddType(p1,p2)	callex(mpd->L2_AddType,mpd->a6stat,p1,p2)
#define L2_AddRDispID(p1,p2,p3)	callex(mpd->L2_AddRDispID,mpd->a6stat,p1,p2,p3)
#define L2_Detach(p1)		callex(mpd->L2_Detach,mpd->a6stat,p1)
#define L2_Send(p1,p2,p3,p4)	callex(mpd->L2_Send,mpd->a6stat,p1,p2,p3,p4)
#define L2_Send_fb(p1,p2,p3,p4)	callex(mpd->L2_Send_fb,mpd->a6stat,p1,p2,p3,p4)
#define L2MB_putnet(p1)		callex(mpd->L2_Putnet,mpd->a6stat,p1)
#define L2_Receive(p1)		callex(mpd->L2_Receive,mpd->a6stat,p1)
#define L2_SetDebug(p1)		callex(mpd->L2_SetDebug,mpd->a6stat,p1)
#define get_boardID(p1)		callex(mpd->get_boardID,mpd->a6stat,p1)
#define get_log_boardID(p1)	callex(mpd->get_log_boardID,mpd->a6stat,p1)

#endif   /* USE_FUNCTION_LABELS */

#define m_cat(p1,p2)		callex(mpd->m_cat,mpd->a6stat,p1,p2)
#define m_copy(p1,p2,p3)	((struct mbuf *)callex(mpd->m_copy,mpd->a6stat,p1,p2,p3))
#define m_copydata(p1,p2,p3,p4)	callex(mpd->m_copydata,mpd->a6stat,p1,p2,p3,p4)
#define m_pullup(p1,p2)		callex(mpd->m_pullup,mpd->a6stat,p1,p2)
#define m_adj(p1,p2)		callex(mpd->m_adj,mpd->a6stat,p1,p2)
#define m_get(p1,p2)		((struct mbuf*)callex(mpd->m_get,mpd->a6stat,p1,p2))
#define m_getclr(p1,p2)		((struct mbuf*)callex(mpd->m_getclr,mpd->a6stat,p1,p2))
#define m_clget(p1)		callex(mpd->m_clget,mpd->a6stat,p1)
#define m_clfree(p1)		callex(mpd->m_clfree,mpd->a6stat,p1)
#define m_free(p1)		((struct mbuf*)callex(mpd->m_free,mpd->a6stat,p1))
#define m_freem(p1)		callex(mpd->m_freem,mpd->a6stat,p1)
#define m_getpag()		callex(mpd->m_getpag,mpd->a6stat)
#define m_putpag(p1)		callex(mpd->m_putpag,mpd->a6stat,p1)

/*------- multi interface entry calls -------------------------------------*/

#define L2_Init_if(if,p1) 	callex((mpd+if)->L2_Init,(mpd+if)->a6stat,p1)
#define L2_Stop_if(if)		callex((mpd+if)->L2_Stop,(mpd+if)->a6stat)
#define L2_AttProto_if(if,p1,p2,p3,p4,p5) \
				callex((mpd+if)->L2_AttProto,(mpd+if)->a6stat,p1,p2,p3,p4,p5)
#define L2_AttPort_if(if,p1,p2,p3,p4,p5) \
				callex((mpd+if)->L2_AttPort,(mpd+if)->a6stat,p1,p2,p3,p4,p5)
#define L2_AddType_if(if,p1,p2)	callex((mpd+if)->L2_AddType,(mpd+if)->a6stat,p1,p2)
#define L2_AddRDispID_if(if,p1,p2,p3)	callex((mpd+if)->L2_AddRDispID,(mpd+if)->a6stat,p1,p2,p3)
#define L2_Detach_if(if,p1)		callex((mpd+if)->L2_Detach,(mpd+if)->a6stat,p1)
#define L2_Send_if(if,p1,p2,p3,p4)	callex((mpd+if)->L2_Send,(mpd+if)->a6stat,p1,p2,p3,p4)
#define L2_Send_fb_if(if,p1,p2,p3,p4)	callex((mpd+if)->L2_Send_fb,(mpd+if)->a6stat,p1,p2,p3,p4)
#define L2MB_putnet_if(if,p1)		callex((mpd+if)->L2_Putnet,(mpd+if)->a6stat,p1)
#define L2_Receive_if(if,p1)		callex((mpd+if)->L2_Receive,(mpd+if)->a6stat,p1)
#define L2_SetDebug_if(if,p1)		callex((mpd+if)->L2_SetDebug,(mpd+if)->a6stat,p1)
#define get_boardID_if(if,p1)		callex((mpd+if)->get_boardID,(mpd+if)->a6stat,p1)
#define get_log_boardID_if(if,p1)	callex((mpd+if)->get_log_boardID,(mpd+if)->a6stat,p1)

extern int callex();
extern MPMOD *mpd;

#endif	/* MP */



/*------------ LAYER 2 - Action Structures ---------------------------------*/
/*
 * mode bit definitions
 */
#define L2_PROMISCUOUS	0x8000		/* set controller to promiscuous mode*/
#define L2_SRCTRANSP	0x4000		/* run L2 in src transparency mode*/
#define L2_USE_DMA	0x2000		/* use DMA for copy operations  */

struct L2M_init_p {
	u_short	L_mode;			/* Lance operation mode             */
	u_char	my_addr[6];		/* my own ETHERNET ID, overrides the*/
					/* ONBOARD Ethernet ID              */
	u_char	**multi_addr;		/* a pointer to a list of Multicast */
					/* addresses                        */
	u_long	License;		/* the License number of the board  */
	u_char	vector;			/* Bus Interrupt vector             */
	u_char  level;			/* Bus Interrupt Level (for VLAN only*/
	u_short dma_modes;		/* operational modes of opt VME dma */
	u_long	a32_base;		/* base address of master board     */
	u_long  a64_base;		/* hihg lword of master base if A64 */
};

struct L2_attproto {
	u_long	proto;			/* protocol-id to be attached        */
	long	(*ifcall)();		/* if-function, to be called from L2 */
	long	a6stat;			/* static storage ptr for 680xx machines */
};

struct L2C_attp_p {			/* Attach Port Structure            */
	u_long	port;			/* the number of the port           */
#ifdef	TRANSPUTER
	long	ifcall;			/* dummy */
	long	dispcall;		/* dummy */
#else	/* not TRANSPUTER */
	long	(*ifcall)();		/* if-function, to be called from L2 */
	long	(*dispcall)();		/* dispatcher-function, to be called from L2 */
#endif /* not TRANSPUTER */
	long	a6stat;			/* static storage ptr for 680xx machines */
	u_short	type;			/* the Ethernet type to be assigned to*/
};

struct L2_rcv {
	UCHAR *addr;
	ULONG len;
	ULONG (*rcv_func)();
	UCHAR *a6stat;
};

struct L2_send {
	UCHAR *addr;
	ULONG len;
	UCHAR ethid[6];
	USHORT type;
};

struct L2C_addvect {
	u_long	port;			/* the number of the port */
	u_char	board_vector;		/* IRQ vector to use for the port */
	u_char	irq_level;		/* IRQ level to use for the port */
};

struct meminfo {
	ULONG	sys,
		mbuf,
		page,
		proc;
};

struct taskinfo {
	USHORT	id,
		state;
	ULONG	pc;
};

/*---------- TCP/IP - Action Structures -----------------------------------*/

typedef struct BCB {
	u_char	*b_addr;
	short	 b_len;
	short	 b_msglen;
} BCB;

struct S_CopyData {                     /* Copy Data Action */
	u_char	*Cpto;
	u_char	*Cpfrom;
	long	Cplen;
};

struct S_Selwakeup {                   /* Select-Wake-up-Call Action */
	caddr_t	procd;
	int	socket;
	int	which;
};

struct Par_Socket {                    /* Socket-Call Action */
	int	dom;
	int	type;
	int	proto;
	u_long	uid;
	int	psock;
};

struct Par_Bind {                      /* Bind-Call Action */
	int	socket;
	caddr_t	name;
	int	namelen;
};

struct Par_Listen {                    /* Listen-Call Action */
	int	socket;
	int	backlog;
};

struct Par_Accept {                    /* Accept-Call Action */
	int	socket;
	caddr_t	name;
	int	*anamelen;
};

struct Par_Connect {                   /* Connect-Call Action */
	int	socket;
	caddr_t	name;
	int	namelen;
};

struct Par_Sendto {                   /* Sendto-Call Action */
	int	socket;
	caddr_t	buf;
	int	len;
	int	flags;
	caddr_t	to;
	int	tolen;
};

struct Par_Send {                     /* Send-Call Action */
	int	socket;
	caddr_t	buf;
	int	len;
	int	flags;
};

/* start of changes made for SIAN_ABC */
struct Par_Sendx {                     /* Send-Call Action */
	int	socket;		       /* special for H.SIAN, ABC */
	caddr_t	sbuf;                  /* ptr to slave local memory */
	caddr_t	lbuf;                  /* ptr to master local memory */
	int	len;
	int	flags;
};

struct sysreqmem {
	ULONG memsize;
	UCHAR *memadr;		/* actually contains the address */
};

struct sysretmem {
	ULONG memsize;
	UCHAR *memadr;
};
/* end of changes made for SIAN_ABC */

struct Par_Sendmsg {                  /* Sendmsg-Call Action */
	int	socket;
	caddr_t	msg;
	int	flags;
};

struct Par_Recvfrom {                 /* Receive-From-Call Action */
	int	socket;
	caddr_t	buf;
	int	len;
	int	flags;
	caddr_t	from;
	int	*fromlenaddr;
};

struct Par_Recv {                     /* Receive-Call Action */
	int	socket;
	caddr_t	buf;
	int	len;
	int	flags;
};

struct Par_Recvmsg {                  /* Receive-Message-Call Action */
	int	socket;
	caddr_t	msg;
	int	flags;
};

struct Par_Shutdown {                 /* Shutdown-Call Action */
	int	socket;
	int	how;
};

struct Par_Setsockopt {               /* Set-Socket-Option-Call Action */
	int	socket;
	int	level;
	int	name;
	caddr_t	val;
	int	valsize;
};

struct Par_Getsockopt {               /* Get_Socket-Option-Call Action */
	int	socket;
	int	level;
	int	name;
	caddr_t	val;
	int	*avalsize;
};

struct Par_Getsockname {              /* Get-Socket-Name-Call Action */
	int	socket;
	caddr_t	asa;
	int	*alen;
};

struct Par_Getpeername {              /* Getpeername-Call Action */
	int	socket;
	caddr_t	asa;
	int	*alen;
};

struct Par_Ioctl {                    /* I/O-Control-Call Action */
	int	socket;
	u_long	cmd;
	caddr_t	cmarg;
};

struct Par_Close {                    /* Socket-Close-Call Action */
	int	socket;
};

struct Par_Select {                   /* Select-Call Action */
	int	socket;
	caddr_t	procd;
	int	flag;
	int	clear_or_set;
};

struct Par_Getstataddr {              /* Get-Statistic-information-addr-Call*/
	int	socket;
	int	type;
};

struct Par_set_dbgopt {		     /* used for ISO/OSI */
	int sock;
	u_char dbg_opt;
	u_char dbg_cmd;
};

struct Par_Sock_DropData {		     /* Drop Data from Socket Buffer */
	u_long psockbuf;
	u_long data_len;
};

/*---------- the common structure of any Action via NIF ------------------*/

#define TPHEADER 16			/* only for Transputers:	*/
					/* size of common header 	*/

struct nifpar {
	u_long	Command;
	u_long	Status;
	u_long	Errno;
	u_short	PID;
	u_short	pad;			/* align on 4 byte boundary */
	union {
		struct	L2M_init_p init;
		struct	L2C_attp_p attp;
		struct	L2C_addvect addvect;
		struct  L2_send L2_send;
		struct	L2_rcv L2_rcv;
		struct	L2_attproto L2_attproto;
		struct	BCB bcb;
		struct	S_CopyData cpdat;
		struct	S_Selwakeup S_Selwakeup;
		struct	Par_Socket Par_Socket;
		struct	Par_Bind Par_Bind;
		struct	Par_Listen Par_Listen;
		struct	Par_Accept Par_Accept;
		struct	Par_Connect Par_Connect;
		struct	Par_Sendto Par_Sendto;
		struct	Par_Send Par_Send;
		struct	Par_Sendmsg Par_Sendmsg;
		struct	Par_Recvfrom Par_Recvfrom;
		struct	Par_Recv Par_Recv;
		struct	Par_Recvmsg Par_Recvmsg;
		struct	Par_Shutdown Par_Shutdown;
		struct	Par_Setsockopt Par_Setsockopt;
		struct	Par_Getsockopt Par_Getsockopt;
		struct	Par_Getsockname Par_Getsockname;
		struct	Par_Getpeername Par_Getpeername;
		struct	Par_Ioctl Par_Ioctl;
		struct	Par_Close Par_Close;
		struct	Par_Select Par_Select;
		struct	Par_Getstataddr Par_Getstataddr;
		u_char	ethid[6];
		u_long	debuglevel;
		struct meminfo meminfo;
		struct taskinfo *taskinfo;
		u_long	license;
		struct sysreqmem sysreqmem;	/* specially for SIAN_ABC */
		struct sysretmem sysretmem;	/* specially for SIAN_ABC */
		struct Par_Sendx Par_Sendx;	/* specially for SIAN_ABC */
		struct Par_set_dbgopt Par_set_dbgopt; /* ISO/OSI dbg opt  */
		struct Par_Sock_DropData Par_Sock_DropData;
       } Opt;
};

/*-------- nif - COMMANDS ----------------------------------------------*/
/*
 * Commands frome the masterboard to the slaveboard.
 */
#define L2_INIT			1	/* L2 - Init			*/
#define L2_ATTP			2	/* L2 - Attach Port		*/
#define L2_SEND			3	/* L2 - Send Data		*/
#define L2_ETHID		4	/* get the boards Ethernet ID   */
#define L2_DEBUG		5	/* set layer 2 debug level      */
#define L2_DETACH		6	/* detach a port from operation */
#define L2_STOP			7	/* stop Layer 2 operation       */
#define L2_VECTOR		8	/* send IRQ vector and IRQ level*/
					/* for a specified protocol to  */
					/* Layer 2			*/
#define L2_PHYS_ETHID		9	/* get the boards physical	*/
					/* Ethernet ID   		*/
#define L2_LOG_ETHID		10	/* get the boards logical	*/
					/* Ethernet ID   		*/

#define SOC_INIT		11	/* Initialize Network Software	*/
#define SOC_SOCKET		12	/* Socket call			*/
#define SOC_BIND		13	/* Bind call			*/
#define SOC_LISTEN		14	/* Listen call			*/
#define SOC_ACCEPT		15	/* Accept call			*/
#define SOC_CONNECT		16	/* Connect call			*/
#define SOC_SENDTO		17	/* Sendto call			*/
#define SOC_SEND		18	/* Send call			*/
#define SOC_SENDMSG		19	/* Sendmsg call			*/
#define SOC_RECVFROM		20	/* Recvfrom call		*/
#define SOC_RECV		21	/* Recv call			*/
#define SOC_RECVMSG		22	/* Recvmsg call			*/
#define SOC_SHUTDOWN		23	/* Shutdown call		*/
#define SOC_GETSOCKOPT		24	/* Getsockopt call		*/
#define SOC_SETSOCKOPT		25	/* Setsockopt call		*/
#define SOC_GETSOCKNAME		26	/* Getsockname call		*/
#define SOC_GETPEERNAME		27	/* Getpeername call		*/
#define SOC_IOCTL		28	/* Ioctl call for sockets	*/
#define SOC_CLOSE		29	/* Close call for sockets	*/
#define SOC_SELECT		30	/* Select call for sockets	*/
#define SOC_GETSTATDATA		31	/* Call for netstat utility	*/
#define SOC_GETSTATADDR		32	/* Call for netstat utility	*/
#define SOC_GETSTAT_AT		33	/* Call for netstat utility	*/
#define SOC_TEST_LICENSE	34	/* Test license number		*/
#define MEMINFO			35	/* get Kernel Memory info       */
#define	GET_LICENSE		36	/* get license number		*/
#define L2_ATTPROTO		37	/* attach protocol		*/
#define TASKINFO		38	/* get Kernel Process info	*/
#define SYS_REQMEM		39	/* get system memory		*/
#define SYS_RETMEM		40	/* return allocated  system mem */
#define SOC_SENDX		41	/* special send call		*/
#define SOC_SET_DBGOPT		42	/* set/del ISO/OSI dbg options  */
#define SOC_DROPDATA		49	/* drop data from socket buffer */

/*
 * Commands from the slaveboard to the masterboard.
 */
#define L2_RCV			101	/* L2 S2H - receive data        */
#define	S_COPYIN		102	/* Copy data from masterboard	*/
					/* to slaveboard		*/
#define	S_COPYOUT		103	/* Copy data from slaveboard	*/
					/* to masterboard		*/
#define S_SELWAKEUP		104	/* Wakeup for select()		*/
#define	S_COPYOUT_M		105	/* Copy data in mbuf chain from */
					/* slaveboard to masterboard	*/

/*-------- MBox-IRQ - Codes  -------------------------------------------*/

#define IRQ_MGET		1	/* get a mbuf from slave 	*/
#define IRQ_MPUT		2       /* put mbuf back to slave 	*/
#define IRQ_ActH2S		3       /* Action-Host-to-Slave 	*/
#define IRQ_ActS2H		4       /* Action-Slave-to-Host 	*/
#define IRQ_PGET		5       /* put page 			*/
#define IRQ_PPUT		6       /* put page 			*/
#define IRQ_SNDRAW		7       /* send raw data 		*/
#define IRQ_RCVRAW		8       /* receive raw data 		*/
#define IRQ_SIGNAL		9       /* wake up slave process 	*/
#define	IRQ_RTCOPLEN		10	/* return copied data length	*/

/*-------- Protocol numbers for commands to the slaveboard -------------*/
#define COMPROT_L2		0	/* all L2 primitives */
#define	COMPROT_OS9		4	/* Protocol = OS9Net		*/
#define	COMPROT_TCPIP		5	/* Protocol = TCP/IP		*/
#define	COMPROT_DECNET		6	/* Protocol = DECNet		*/
#define	COMPROT_ISO		7	/* Protocol = ISO/TP		*/
#define	COMPROT_CNAPS		8	/* Protocol = private, CNAPS	*/
#define COMPROT_TOKEN		9	/* Protocol = IBM TOKEN RING	*/

#endif       /* __NIF__ */
