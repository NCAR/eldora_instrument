/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : customize.h
*
* Description : CUSTOMIZE-specific dummy definitions.
*
*		NOTE: THESE DEFINITIONS MUST BE SET BY THE CUSTOMER !!!
*
* Author      : D.Mueller
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
* 960302 dm Initial version
******************************************************************************
******************************************************************************/


#define CUSTOMIZE_MODULE_ADDRESS	0x0
#define CUSTOMIZE_LICENSE		0x0
#define CUSTOMIZE_IRQ_VEC		0x0
#define CUSTOMIZE_IRQ_LVL		0x0
#define CUSTOMIZE_IRQ_PRIOR		0x0
#define CUSTOMIZE_BOARD_TYPE		0x0
#define CUSTOMIZE_SIGWAKE		0x0
#define CUSTOMIZE_IRQ_MASK_REGISTER	*((u_short *)0x00000000)      /* fill in reg. address */
#define CUSTOMIZE_IRQ_MASK		0x0
#define CUSTOMIZE_PID			0x0
#define UNTIL_SIGNAL_ARRIVES		0x0
#define GIVE_UP_TIMESLICE		0x0
