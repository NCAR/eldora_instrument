/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : customize.c
*
* Description : CUSTOMIZE-specific dummy functions.
*
*		NOTE: THESE FUNCTIONS MUST BE REPLACED BY THE CUSTOMER !!!
*
* Author      : D. Mueller
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
*	    Included main() from main.c, since that file is entirely useless.
* 951219 dm Initial version.
******************************************************************************
******************************************************************************/

#include <natdefs.h>

FUNCTION void main()
{
	/*
	 * dummy main routine to make the modules linkable
	 * shall be replaced by customer's application
	 */

	P_Socket(1, 1, 1);
}


FUNCTION void CUSTOMIZE_SLEEP(n)
int n;
{
	return;
}

FUNCTION int CUSTOMIZE_SIGNAL_PROCESS(pid, sig)
int pid, sig;
{
	return( TRUE );
}

FUNCTION int CUSTOMIZE_INSERT_IRQ(vector, prior, irq_handler, port)
u_char vector, prior;
void (*irq_handler)();
u_char *port;
{
	return( TRUE );
}

FUNCTION void CUSTOMIZE_DELETE_IRQ(vector, prior, port)
u_char vector, prior;
u_char *port;
{
	return;
}

FUNCTION void CUSTOMIZE_DEBUG_PRINT(format)
char *format;
{
	return;
}

