#ifndef	__MACH_MACHPARAM__
#define	__MACH_MACHPARAM__

#ifndef HZ
#define HZ 100
#endif

#ifndef BYTE_ORDER
#include "endian.h"
#endif


#define	NBPG		1460
#define	CLSIZE		1

#endif	/* __MACH_MACHPARAM__ */
