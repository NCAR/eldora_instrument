/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : nifmisc.c
*
* Description : Specific Network InterFace (NIF) routines
*
* Author      : H.Koerte
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
* 	    Added some default initialization to L2_Init().
*	    Corrected known bug in L2_Init(), L2_PhyEthID(), L2_AddVect(),
*		L2_Detach and L2_Stop()	when initializing nifp pointer,
*		was to V_Port always (true for MS360 only !) and should be
*		to m instead (if not MS360).
* 951219 hk Initial version for CUSTOMIZE, adapted from original nifms360.c
******************************************************************************
******************************************************************************/


#include <natdefs.h>
#define VAR extern

#include <mbuf.h>
#include <nif.h>
#include <neterr.h>

#include <customize.h>			/* CUSTOMIZE here */

VAR u_char *V_Port;			/* address of module on bus */
VAR u_char *V_Nif;			/* address of module's NIF field */

VAR int sockprintfs;			/* debuf level */
VAR struct mbuf localm;			/* local copy of mbuf */


/*--------------------------------------------------------------------------*/
FUNCTION struct mbuf *wait_sl()		/* poll for Action Slave->Host	    */
/*--------------------------------------------------------------------------*/
{
	register NIF *nifp;
	register struct mbuf *m;

	nifp = (NIF *)V_Nif;

	while ((m = (struct mbuf *)(nifp->ActS2H)) == 0) {
		CUSTOMIZE_SLEEP(GIVE_UP_TIMESLICE);
	}
	nifp->ActS2H = (struct mbuf *)0;
	m = (struct mbuf *)((u_long)m | (u_long)V_Port);

	return(m);
}

/*--------------------------------------------------------------------------*/
FUNCTION int L2_Init(initpar)		/* Layer 2 basic initialization     */
/*--------------------------------------------------------------------------*/
	register struct L2M_init_p *initpar;
{
	register struct mbuf *m;
	register struct nifpar *nifp;
	int error, i;

	m = get_mbuf();
	if (m == 0) {
		return (E_NOMEM);
	}

	/*
	 * set up L2_init command to slaveboard
	 */

	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = L2_INIT;
	nifp->Status = 0;
	nifp->PID = 0;
#ifdef MS360
	nifp->Opt.init.L_mode     = initpar->L_mode;
#else
	nifp->Opt.init.L_mode     = (u_short)0x00;
#endif /* MS360 *//
	nifp->Opt.init.vector     = initpar->vector;
	nifp->Opt.init.level      = initpar->level;
	nifp->Opt.init.License    = initpar->License;
	nifp->Opt.init.dma_modes  = (u_short)0x00;
	nifp->Opt.init.a32_base   = (u_long)0x00;
	nifp->Opt.init.a64_base   = (u_long)0x00;
	nifp->Opt.init.multi_addr = (u_char *)0x00;
	for(i=0;i<6;i++)
		nifp->Opt.init.my_addr[0] = initpar->my_addr[i];
						/* IEEE address might overwrite*/
						/* onboard ID		    */

#ifdef MS360
	cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	action(m);				/* carry out L2_init command */

	m = wait_sl();

#ifdef MS360
	ms360_set_win(V_Port,m);
#endif /* MS360 */

	nifp = mtod(m, struct nifpar *);
	error=nifp->Status;
	put_mbuf(m);		/* return the buffer to the slave */
	return(error);
}

/*--------------------------------------------------------------------------*/
FUNCTION int L2_PhysEthID(ethid)	/* read IEEE address from slaveboard*/
/*--------------------------------------------------------------------------*/
	u_char *ethid;
{
	register struct mbuf *m;
	register struct nifpar *nifp;
	int error, i;

	m = get_mbuf();
	if (m == 0) {
		return (E_NOMEM);
	}
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = L2_ETHID;
	nifp->Status = 0;
	nifp->PID = 0;

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,32);
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,32);
#endif /* MS360 */

	action(m);

	m = wait_sl();

#ifdef MS360
	ms360_set_win(V_Port,m);
	nifp = mtod((struct mbuf*)V_Port, struct nifpar *);
#else
	nifp = mtod(m, struct nifpar *);
#endif /* MS360 */

	if((error=nifp->Status) != OK) {
		put_mbuf(m);		/* return the buffer to the slave */
		return(error);
	}

	/*
	 * Get back the returned Ethernet ID.
	 */
	for(i=0;i<6;i++) {
		ethid[i] = nifp->Opt.ethid[i];
	}
	put_mbuf(m);		/* return the buffer to the slave */
	return(OK);
}

/*--------------------------------------------------------------------------*/
FUNCTION int L2_AddVect(proto,vector,level)
				/* set up Interrupt vector on slaveboard   */
/*--------------------------------------------------------------------------*/
	u_long proto;
	u_char vector, level;
{
	register struct mbuf *m;
	register struct nifpar *nifp;
	int error, i;

	m = get_mbuf();
	if (m == 0) {
		return (E_NOMEM);
	}
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = L2_VECTOR;
	nifp->Status = 0;
	nifp->PID = 0;
	nifp->Opt.addvect.port = proto;
	nifp->Opt.addvect.board_vector = vector;
	nifp->Opt.addvect.irq_level = level;

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	action(m);

	m = wait_sl();

#ifdef MS360
	ms360_set_win(V_Port,m);
	nifp = mtod((struct mbuf*)V_Port, struct nifpar *);
#else
	nifp = mtod(m, struct nifpar *);
#endif /* MS360 */

	if((error=nifp->Status) != OK) {
		put_mbuf(m);		/* return the buffer to the slave */
		return(error);
	}

	put_mbuf(m);			/* return the buffer to the slave */
	return(OK);
}

/*-------------------------------------------------------------------------*/
FUNCTION L2_Detach(proto)		/* detachs a protocol port         */
/*-------------------------------------------------------------------------*/
	u_long proto;
{
	register struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		return (E_NOMEM);
	}

#ifdef MS360
	ms360_set_win(V_Port,m->m_dat);
	nifp = mtod((struct mbuf*)V_Port, struct nifpar *);
#else
	nifp = mtod(m, struct nifpar *);
#endif /* MS360 */

	nifp->Opt.attp.port = proto;
	nifp->Command = L2_DETACH;
	action(m);			/* fire and forget */
	return(OK);
}

/*-------------------------------------------------------------------------*/
	FUNCTION L2_Stop()              /* shutdown Layer 2 on SLaveboard  */
/*-------------------------------------------------------------------------*/
{
	register struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		return (E_NOMEM);
	}

#ifdef MS360
	ms360_set_win(V_Port,m->m_dat);
	nifp = mtod((struct mbuf*)V_Port, struct nifpar *);
#else
	nifp = mtod(m, struct nifpar *);
#endif /* MS360 */

	nifp->Command = L2_STOP;
	action(m);			/* fire and forget */
	return(OK);
}

