#ifndef WINFUNCS__H
#define WINFUNCS__H

#ifdef __cplusplus
extern "C" {
#endif

int _kbhit(void);

#ifdef __cplusplus
}
#endif
	
#endif

