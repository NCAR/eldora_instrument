/******************************************************************************
*******************************************************************************
*                                                                             *
*      NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*      N NNNNN        N               AAA                  T TTTTT            *
*      NN NNNNN       N              AAAAA                 T TTTTT            *
*      N N NNNNN      N             A AAAAA                T TTTTT            *
*      N  N NNNNN     N            A A AAAAA               T TTTTT            *
*      N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*      N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*      N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*      N      N NNNNN N        A         A AAAAA           T TTTTT            *
*      N       N NNNNNN       A           A AAAAA          T TTTTT            *
*      N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                        OO                         OO                 OO     *
*                                                                             *
*      Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*         Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++2241/3989-0         *
*                                                                             *
*******************************************************************************
*******************************************************************************
*
* Module      : socksend.c
*
* Description : send data over socket to specified host
*
* Author      : unknown
*
*******************************************************************************
*******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*	All rights reserved. Copying, compilation, modification,
*	distribution or any other use whatsoever of this material
*	is strictly prohibited except in accordance with a Software
*	License Agreement with N.A.T. GmbH.
*
*******************************************************************************
*******************************************************************************
*
* Module's Description Record:
* ============================
*
* $ProjectName$
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
*
030403 cg added UDP support;
011117 cg initial version, derived from NAT socksend.c;

*******************************************************************************
*******************************************************************************
*/

/*-----------------------------------------------------------------------------

If socksend returns 'socksend: connect(socket) error - Network is unreachable'
a route for the network has to be added to the kernel routing tables.

Example for Linux: Adding network route 10.0.0.0 for device eth0 type:

# ping 10.0.0.1
PING 10.0.0.1 (10.0.0.1): 56 data bytes
ping: sendto: Network is unreachable
ping: wrote 10.0.0.1 64 chars, ret=-1
...
#
# route
Kernel IP routing table
Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
192.168.0.0     *               255.255.255.0   U     0      0        0 eth0
# route add -net 10.0.0.0 netmask 255.0.0.0 dev eth0
# route
Kernel IP routing table
Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
192.168.0.0     *               255.255.255.0   U     0      0        0 eth0
10.0.0.0        *               255.0.0.0       U     0      0        0 eth0
#
# ping 10.0.0.1
PING 10.0.0.1 (10.0.0.1): 56 data bytes
--- 10.0.0.1 ping statistics ---
13 packets transmitted, 0 packets received, 100% packet loss
#

The host was not connected but the ping can be monitored using tcpdump,
ethereal, ...

NOTE: private IP address spaces for networks are (RFC 1918):
      Class A network: 10.x.x.x
      Class B network: 172.16.x.x - 172.31.x.x
      Class C network: 192.168.x.x

-----------------------------------------------------------------------------*/



/*****************************************************************************/
/*	COMMON CONFIGURATION						     */
/*****************************************************************************/



/*****************************************************************************/
/*	INCLUDES							     */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>		/* malloc, free */
#include <string.h>		/* strlen, strncpy */
#include <unistd.h>		/* close */
//#include <sys/types.h>
//#include <time.h>		/* gettimeofday, timeval */
//#include <sys/socket.h>
//#include <netinet/tcp.h>
#include <netinet/in.h>		/* sockaddr_in */
#include <netdb.h>		/* gethostbyname */
#include <errno.h>

#include "getopts.h"		/* parse command line options */



/*****************************************************************************/
/*	PRIVATE MACROS							     */
/*****************************************************************************/

/*
 * version
 */
#define SOCKSEND_REL	"0.0.2"

/*
 * debug
 */
#ifndef printd
#define printd		printf
#endif

#ifndef fprintd
#define fprintd		fprintf
#endif

#define PRINTD		if(dbg || cfg.dbg) printd

#define PRINTE(fmt,args...) \
{ \
	char db[1024], *db_cur = db; \
	db_cur += sprintf(db, "%s: ", argv[0]); \
	db_cur += sprintf(db_cur, fmt, ## args); \
	if(errno) sprintf(db_cur-1, " - "); \
	fprintd(stderr, "%s", db); \
	if(errno) perror(""); \
}



/*
 * default parameter
 */
#define LOOPS	10
#define BUFLEN	128



/*
 * missing types
 */
#ifndef u_char
#define u_char	unsigned char
#endif

#ifndef u_short
#define u_short	unsigned short
#endif

#ifndef u_int
#define u_int	unsigned int
#endif

#ifndef u_long
#define u_long	unsigned long
#endif


/*****************************************************************************/
/*	PRIVATE DATA TYPES						     */
/*****************************************************************************/

/*
 * socksend configuration
 * <x>: option parameter
 */
typedef struct socksend_configuration {
	char shost[256];	/* s: source host */
	u_long sip;		/* source ip address */
	char dhost[256];	/* d: destination host */
	u_long dip;		/* destination ip address */
	int port;		/* p: port number */
	int udp;		/* u: use UDP instead of TCP */
	u_long blen;		/* l: transmit buffer length */
	u_char *b;		/* buffer to send */
	int pattern_num;	/* a: use ascending numbers as buffer pattern */
	u_char pattern;		/* P: static pattern for transmit buffer */
	u_long loops;		/* L: number of transmit loops, -1: endless */
	int dbg;		/* v: enable run-time debug */
	int time_print;		/* t: enable timing printout */
	int version;		/* V: print version only */
} SOCKSEND_CFG;



/*****************************************************************************/
/*	PRIVATE FUNCTION PROTOTYPES					     */
/*****************************************************************************/

static void print_usage(char *name);
static int set_socksend_cfg(int argc, char **argv, SOCKSEND_CFG *cfg);
static u_long ip_str2num(void *vstr);



/*****************************************************************************/
/*	PRIVATE GLOBALS							     */
/*****************************************************************************/

int dbg = 0;					       /* compile-time debug */
static SOCKSEND_CFG cfg;			   /* socksend configuration */



/*****************************************************************************/
/*	PUBLIC GLOBALS							     */
/*****************************************************************************/



/*****************************************************************************/
/*	EXTERNAL REFERENCES						     */
/*****************************************************************************/



/*****************************************************************************/
/*	PUBLIC FUNCTION DEFINITIONS					     */
/*****************************************************************************/

/*---------------------------------------------------------------------------*
Function:	main routine
Parameters:	argc: number of command line arguments
		argv: command line arguments
Input:		command line arguments
Output:		none
Return:		0 => ok
		!0 => error
*----------------------------------------------------------------------------*/

int main(argc,argv)
	int argc;
	char *argv[];
{
	int s;						/* socket descriptor */
	int len;				  /* length of received data */
	int i1;							  /* counter */
	struct sockaddr_in sa;		   /* internet socket address struct */
	struct hostent *hp;		       /* result of host name lookup */
	char *dhost;			      /* pointer to remote host name */
	int count;
	int numb = 0;
	int loops;
	int datalen;
	int result = 0;
#ifdef NEVER
	double timed;
	double kps;
	struct timeval t0,t1,t2,td;
	/*
       struct timeval {
               long tv_sec;        seconds
               long tv_usec;       microseconds
       };

	*/
#endif

	if((result = set_socksend_cfg(argc, argv, &cfg)) != 0) {
		print_usage(argv[0]);
		exit((result < 0) ? 1 : 0);
	}

	dhost = cfg.dhost;

	/*
	 * Look up the specified hostname
	 */
	if((hp = gethostbyname(dhost)) == NULL) {
		PRINTE("unknown destination '%s'\n", dhost);
		exit(1);
	}

#ifdef NEVER
	datalen = BUFLEN;
	printd("Buffergroesse? (%d)  ",datalen);
	fgets(in_line, 60, stdin);
	if(strlen(in_line) > 0)
		sscanf(in_line,"%d",&datalen);

	loops = LOOPS;
	printd("Loops? (%d)  ",loops);
	fgets(in_line, 60, stdin);
	if(strlen(in_line) > 0)
		sscanf(in_line,"%d",&loops);
#endif
	datalen = cfg.blen;
	loops = cfg.loops;

	printd("\nDestination   = %d.%d.%d.%d",
		(u_char)hp->h_addr[0], (u_char)hp->h_addr[1],
		(u_char)hp->h_addr[2], (u_char)hp->h_addr[3]);
	printd("\b\nBuffergroesse = %d Bytes\n",datalen);
	printd("Loops         = %d\n",loops);

	/*
	 * Put host's address and address type into socket structure
	 */
	memcpy((char*)&sa.sin_addr,(char*)hp->h_addr,hp->h_length);
	sa.sin_family = hp->h_addrtype;
	sa.sin_port = htons((short)cfg.port);

	/*
	 * Allocate an open socket
	 */
	if(cfg.udp) s = socket(AF_INET,SOCK_DGRAM, 17);		 /* use UDP */
	else s = socket(AF_INET,SOCK_STREAM, 6);		 /* use TCP */

	if(s < 0) {
		PRINTE("socket(%d) %s error\n",
			s, cfg.udp ? "UDP" : "TCP");
		exit(1);
	}

//	setsockopt(s, SOL_SOCKET, SO_DEBUG, "1", 4);
	i1 = 16384;
	if (setsockopt(s, SOL_SOCKET, SO_RCVBUF, &i1, sizeof(i1)) < 0) {
		PRINTE("setsockopt(%d) SO_RCVBUF error\n", s);
		exit(1);
	}

	i1 = 16384;
	if (setsockopt(s, SOL_SOCKET, SO_SNDBUF, &i1, sizeof(i1)) < 0) {
		PRINTE("setsockopt(%d) SO_SNDBUF error\n", s);
		exit(1);
	}

#ifdef NEVER
	gettimeofday(&t0, 0);
#endif

	/*
	 * Connect to the remote server
	 */
	if(connect(s,&sa,sizeof(sa)) < 0) {
		PRINTE("connect(%d) error\n", s);
		exit(1);
	}


#ifdef NEVER
	gettimeofday(&t1, 0);
#endif

	for(count = 0; count < loops; count++, numb++) {

		/*
		 * send the request
		 */
		if((len = send(s, cfg.b, datalen, 0)) != datalen) {
			PRINTE("send(%d) buf 0x%lx len %d error\n",
				s, (u_long)cfg.b, datalen);
			exit(1);
		}
//		printd("#%s", !((count+1) % 60) ? "\n" : "");

		/* endless loop */
		if(cfg.loops == -1)
			count--;
	}
	printd("\n");

	if(loops > 0) {
		if((len = send(s, "ENDE", sizeof("ENDE"), 0)) != sizeof("ENDE")) {
			PRINTE("send(%d) ENDE error\n", s);
			exit(1);
		}
	}


	close(s);

#ifdef NEVER
	gettimeofday(&t2, 0);
	if (t2.tv_usec > t0.tv_usec) {
		timed = (t2.tv_sec - t0.tv_sec) * 1000000.0 
				+ (t2.tv_usec - t0.tv_usec);
	} else {
		timed = (t2.tv_sec - 1 - t0.tv_sec) * 1000000.0
				+ (1000000 + t2.tv_usec - t0.tv_usec);
	}
#endif

	free(cfg.b);

#ifdef NEVER
	kps   = ((double)(datalen * numb) / 1024.0) / (timed / 1000000.0);
	printd("%d KBytes sent in %-16.3f sec since open\n",
	         ((datalen * numb) / 1024), timed / 1000000.0);
	printd("       =  %16.3f KBytes/sec\n", kps);

	if (t2.tv_usec > t1.tv_usec) {
		timed = (t2.tv_sec - t1.tv_sec) * 1000000.0 
				+ (t2.tv_usec - t1.tv_usec);
	} else {
		timed = (t2.tv_sec - 1 - t1.tv_sec) * 1000000.0
				+ (1000000 + t2.tv_usec - t1.tv_usec);
	}

	kps   = ((double)(datalen * numb) / 1024.0) / (timed / 1000000.0);
	printd("%d KBytes sent in %-16.3f sec while sending\n",
	         ((datalen * numb) / 1024), timed / 1000000.0);
	printd("       =  %16.3f KBytes/sec\n", kps);

#endif

	return(0);
}



/*****************************************************************************/
/*	PRIVATE FUNCTION DEFINITIONS					     */
/*****************************************************************************/

/*---------------------------------------------------------------------------*
Function:	print usage
Parameters:	name: function name
Input:		none
Output:		none
Return:		none
*----------------------------------------------------------------------------*/

static void print_usage(char *name)
{
	printd("Usage: %s [-s <source>][-d <destination>]\n", name);
	printd("                [-p <port>][-l <length>][-a]\n");
	printd("                [-P <pattern>][-L <loops][-v]\n");
	printd("                [-t][-h][-V]\n");
	printd("       s: source host or source ip address\n");
	printd("       d: destination host or destination ip address\n");
	printd("       p: port number\n");
	printd("       u: use UDP instead of TCP\n");
	printd("       l: transmit buffer length\n");
	printd("       a: use ascending numbers as buffer pattern\n");
	printd("       P: static pattern for transmit buffer\n");
	printd("       L: number of transmit loops, -1: endless\n");
	printd("       v: enable run-time debug\n");
	printd("       t: enable timing printout\n");
	printd("       h: print help\n");
	printd("       V: print version only\n");
}



/*---------------------------------------------------------------------------*
Function:	get socksend confguration from command line
Parameters:	argc: number of command line arguments
		argv: command line parameter
		cfg: where to store parameter
Input:		command line options
Output:		none
Return:		0 => ok
		>0 => ok, but exit
		-1 => internal error
		-2 => option error
*----------------------------------------------------------------------------*/

static int set_socksend_cfg(int argc, char **argv, SOCKSEND_CFG *cfg)
{
	u_char *cur;						   /* cursor */
	int i;							  /* counter */
	int opts = 0;				      /* command line option */
	int result = 0;						   /* result */

	/* check arguments */
	if(cfg == NULL) {
		PRINTE("get_socksend_cfg: internal error - no cfg\n");
		return(-1);
	}

	/* default configuration */
	cur = (u_char *)cfg;
	i = sizeof(SOCKSEND_CFG);
	while(i--)
		*cur++ = '\0';
	
	strncpy(cfg->shost, "localhost", 255);	      /* set struct elements */
	cfg->sip = 0x7f000001;
	strncpy(cfg->dhost, "localhost", 255);
	cfg->dip = 0x7f000001;
	cfg->port = 50001;
	cfg->udp = 0;
	cfg->blen = 128;
	cfg->b = malloc(cfg->blen);
	cfg->pattern_num = 0;
	cfg->pattern = 0xa5;
	cfg->loops = 10;
	cfg->dbg = 0;
	cfg->time_print = 0;

	if(cfg->b == NULL) {				     /* check buffer */
		PRINTE("get_socksend_cfg: internal error - no memory\n");
		return(-1);
	}

	/* get command line options */
	while(opts != EOF) {
		opts = getopts(argc, argv, "s:d:p:l:aP:L:vtuhV");
		switch(opts) {
			case EOF: /* no more options */
				break;

			case '?': /* help or unknown option */
				if((char)optsopt == '?') {
					printd("%s: V"SOCKSEND_REL" (%s %s)\n",
						argv[0], __DATE__, __TIME__);
					result = 1;
				}
				else {
					PRINTE("unkown option '%c'\n",
						(char)optsopt);
					result = -2;
				}
				break;

			case ':': /* missing argument */
				PRINTE("missing arg to option '%c'\n",
					(char)optsopt);
				result = -2;
				break;

			case 's': /* source host */
				strncpy(cfg->shost, optsarg, 255);
				cfg->sip = ip_str2num(cfg->shost);
				if(cfg->sip == -1)
					result = -2;
				break;

			case 'd': /* destination host */
				strncpy(cfg->dhost, optsarg, 255);
				cfg->dip = ip_str2num(cfg->dhost);
				if(cfg->dip == -1)
					result = -2;
				break;

			case 'p': /* port number */
				cfg->port = (atoi(optsarg) & 0xffff);
				break;

			case 'l': /* transmit buffer length */
				free(cfg->b);
				cfg->blen = (u_long)atol(optsarg);
				cfg->b = malloc(cfg->blen);
				if(cfg->b == NULL) {
					PRINTE("get_socksend_cfg: internal error - no memory\n");
					return(-1);
				}
				break;

			case 'a': /* use ascending numbers as buffer pattern */
				cfg->pattern_num = 1;
				break;

			case 'P': /* static pattern */
				cfg->pattern = (u_char)(atoi(optsarg) & 0xff);
				break;

			case 'L': /* number of transmit loops */
				cfg->loops = (u_long)atol(optsarg);
				break;

			case 'v': /* enable run-time debug */
				cfg->dbg = 1;
				break;

			case 't': /* enable timing printout */
				cfg->time_print = 1;
				PRINTE("option 't' yet unsupported\n");
				result = -2;
				break;

			case 'u': /* use UDP instead of TCP */
				cfg->udp = 1;
				break;

			case 'h': /* print help */
			case 'V': /* print version only */
				printd("%s: V"SOCKSEND_REL" (%s %s)\n",
					argv[0], __DATE__, __TIME__);
				result = 1;
				break;

			default: /* default */
				PRINTE("unsupported option '%c'\n",
					(char)optsopt);
				result = -2;
				break;
		}
	}

	/* if ok set left configuration */
	if(result == 0) {
		/* fill buffer with ascending numbers or pattern */
		if(cfg->pattern_num) {
			for(i = 0; i < cfg->blen; i++)
				cfg->b[i] = (u_char)(i & 0xff);
		}
		else {
			for(i = 0; i < cfg->blen; i++)
				cfg->b[i] = cfg->pattern;
		}
	}

	/* clean up in case of error */
	else {
		if(cfg->b)
			free(cfg->b);
	}

	return(result);
}



/*---------------------------------------------------------------------------*
Function:	convert ip address string into number
		NOTE: expects a NULL terminated string
Parameters:	vstr: void pointer to ip string
Input:		none
Output:		none
Return:		!-1 => ok
		-1 => error
*----------------------------------------------------------------------------*/

static u_long ip_str2num(void *vstr)
{
	u_char *str = vstr;				/* ip address string */
	u_char *str_p;					   /* string pointer */
	int dot_count = 0, char_count = 0;			  /* counter */
	u_long num = 0, num_temp = 0;			/* ip address number */
	u_char *num_p = (u_char *)&num;			   /* number pointer */

	/* check argument */
 	if(!str) {
		printd("ip_str2num: no string\n");
		return(-1);
	}

	char_count = strlen(str);
	if((char_count < 7) || (char_count > 15)) {
		printd("ip_str2num: invalid string length\n");
		return(-1);
	}

	char_count = 0;
	for(str_p = str; *str_p != '\0'; str_p++) {
		if((*str_p == '.') && (char_count != 0)) {
			dot_count++;
			char_count = 0;
		}
		else if((*str_p < '0') || (*str_p > '9'))
			num = -1;
		else
			char_count++;
		if(char_count > 3)
			num = -1;
	}

	if((dot_count != 3) || (char_count == 0) || (num == -1)) {
		printd("ip_str2num: invalid ip address '%s'\n", str);
		return(-1);
	}

	/* parse string */
	dot_count = 0;
	num_temp = 0;
	for(str_p = str; *str_p != '\0'; str_p++) {
		if(*str_p != '.') {
			num_temp *= 10;
			num_temp += *str_p - '0';
			if(num_temp > 255) {
				printd("ip_str2num: invalid ip address '%s'\n", str);
				return(-1);
			}
			num_p[dot_count] = num_temp;
		}
		else {
			dot_count++;
			num_temp = 0;
		}
	}

	printd("ip_str2num: '%s' -> %d.%d.%d.%d (0x%08lx)\n",
		str, num_p[0], num_p[1], num_p[2], num_p[3], num);

	return(num);
}

