/******************************************************************************
*******************************************************************************
*                                                                             *
*      NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*      N NNNNN        N               AAA                  T TTTTT            *
*      NN NNNNN       N              AAAAA                 T TTTTT            *
*      N N NNNNN      N             A AAAAA                T TTTTT            *
*      N  N NNNNN     N            A A AAAAA               T TTTTT            *
*      N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*      N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*      N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*      N      N NNNNN N        A         A AAAAA           T TTTTT            *
*      N       N NNNNNN       A           A AAAAA          T TTTTT            *
*      N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                        OO                         OO                 OO     *
*                                                                             *
*      Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*         Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++2241/3989-0         *
*                                                                             *
*******************************************************************************
*******************************************************************************
*
* Module      : sockrcv.c
*
* Description : receive data from specified socket
*
* Author      : unknown
*
*******************************************************************************
*******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*	All rights reserved. Copying, compilation, modification,
*	distribution or any other use whatsoever of this material
*	is strictly prohibited except in accordance with a Software
*	License Agreement with N.A.T. GmbH.
*
*******************************************************************************
*******************************************************************************
*
* Module's Description Record:
* ============================
*
* $ProjectName$
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
*
030408 cg added UDP support;
020127 cg initial version, derived from NAT sockrcv.c;

*******************************************************************************
*******************************************************************************
*/

/*-----------------------------------------------------------------------------

-----------------------------------------------------------------------------*/

/*****************************************************************************/
/*	INCLUDES							     */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>		/* atoi, malloc, free */
#include <string.h>		/* strncmp */
#include <unistd.h>		/* close, fork */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <netdb.h>		/* struct hostent, gethostbyname */
#include <errno.h>

#include "getopts.h"



/*****************************************************************************/
/*	PRIVATE MACROS							     */
/*****************************************************************************/

/*
 * version
 */
#define SOCKRCV_VER	"0.2"

/*
 * debug
 */
#ifndef printd
#define printd		printf
#endif

#ifndef fprintd
#define fprintd		fprintf
#endif

#define PRINTD		if(dbg || cfg.dbg) printd

#define PRINTE(fmt,args...) \
{ \
	char db[1024], *db_cur = db; \
	db_cur += sprintf(db, "%s: ", argv[0]); \
	db_cur += sprintf(db_cur, fmt, ## args); \
	if(errno) sprintf(db_cur-1, " - "); \
	fprintd(stderr, "%s", db); \
	if(errno) perror(""); \
}

/*
 * default parameter
 */
#define BUFLEN		65536			    /* receive buffer length */
#define RCV_PORT	50001				     /* receive port */
#define RCV_HOST	"localhost"
#define MAX_HN_LEN	256			 /* maximum host name length */

/*
 * free buffer
 */
#define BFREE(b)		if(b) free(b)

/*
 * missing types
 */
#ifndef u_char
#define u_char	unsigned char
#endif

#ifndef u_short
#define u_short	unsigned short
#endif

#ifndef u_int
#define u_int	unsigned int
#endif

#ifndef u_long
#define u_long	unsigned long
#endif



/*****************************************************************************/
/*	PRIVATE DATA TYPES						     */
/*****************************************************************************/

/*
 * sockrcv configuration
 * <x>: option parameter
 */
typedef struct sockrcv_configuration {
	char shost[MAX_HN_LEN];	/* s: source host */
	int port;		/* p: port number */
	int udp;		/* open UDP socket */
	int dbg;		/* v: enable run-time debug */
	int time_print;		/* t: enable timing printout */
	u_long blen;		/* l: receive buffer length */
	u_char *b;		/* receive buffer */
} SOCKRCV_CFG;



/*****************************************************************************/
/*	PRIVATE FUNCTION PROTOTYPES					     */
/*****************************************************************************/

static void print_version(char *name);
static void print_usage(char *name);
static void print_help(void);
static int set_sockrcv_cfg(int argc, char **argv, SOCKRCV_CFG *cfg);



/*****************************************************************************/
/*	PRIVATE GLOBALS							     */
/*****************************************************************************/

int dbg = 0;					       /* compile-time debug */
static SOCKRCV_CFG cfg;				    /* sockrcv configuration */



/*****************************************************************************/
/*	PUBLIC GLOBALS							     */
/*****************************************************************************/



/*****************************************************************************/
/*	EXTERNAL REFERENCES						     */
/*****************************************************************************/



/*****************************************************************************/
/*	PUBLIC FUNCTION DEFINITIONS					     */
/*****************************************************************************/

/*---------------------------------------------------------------------------*
Function:	main routine
Parameters:	argc: number of command line arguments
		argv: command line arguments
Input:		command line arguments
Output:		none
Return:		0 => ok
		!0 => error
*----------------------------------------------------------------------------*/

int main(int argc, char *argv[])
{
	int s, t;			/* socket descriptors		*/
	int i1, i2;			/* general purpose integer	*/
	struct sockaddr_in sa, isa;	/* Internet socket address	*/
					/* structures			*/
	struct hostent *hp;             /* result of hostname lookup    */
	int pid;
	int      numb;
	unsigned long	rcv_bytes = 0;

	int i;							  /* counter */
	int result = 0;

	/* set defaults and process command line arguments */
	if((result = set_sockrcv_cfg(argc, argv, &cfg)) != 0) {
		exit((result > 0) ? 0 : 1);
	}

	/* get our own host information */
	if((hp = gethostbyname(cfg.shost)) == 0) {
		PRINTE("unknown host '%s'\n", cfg.shost);
		BFREE(cfg.b);
		exit(1);
	}

	/* print configuration */
	printd("source host:    %s (%d.%d.%d.%d)\n",
		cfg.shost, 
		(u_char)hp->h_addr[0], (u_char)hp->h_addr[1],
		(u_char)hp->h_addr[2], (u_char)hp->h_addr[3]);
	printd("rx port:        %d (%s)\n",
		cfg.port, cfg.udp ? "UDP" : "TCP");
	printd("rx buffer size: %lu\n", cfg.blen);
	PRINTD("debug enabled\n");

	/* put port and address info into socket struct */
	sa.sin_port = htons(cfg.port);
	memcpy((char*)&sa.sin_addr,(char*)hp->h_addr,hp->h_length);
	for(i = 0; i < 8 ; i++)
		sa.sin_zero[i] = 0;
	sa.sin_family = hp->h_addrtype;

	/* open socket for incoming connections */
	if(cfg.udp) {						  /* use UDP */
		if((s = socket(AF_INET, SOCK_DGRAM, 17)) < 0) {
			PRINTE("socket(%d) UDP error\n", s);
			BFREE(cfg.b);
			exit(1);
		}
	}
	else {							  /* use TCP */
		if((s = socket(AF_INET, SOCK_STREAM, 6)) < 0) {
			PRINTE("socket(%d) TCP error\n", s);
			BFREE(cfg.b);
			exit(1);
		}
	}

	/* bind socket struct to port - hear incoming connections */
	if(bind(s, &sa, sizeof(sa)) < 0) {
		PRINTE("bind(%d) error\n", s);
		BFREE(cfg.b);
		exit(1);
	}

	/* limit number of incoming TCP connections to one */
	if(!cfg.udp) {
		if(listen(s, 1) < 0) {
			PRINTE("listen(%d) error\n", s);
			BFREE(cfg.b);
			exit(1);
		}
	}

	/* receive UDP */
	if(cfg.udp) {
		int rx_active = 1;

		while(rx_active) {
			/*
			 * If data available, fill it into receive
			 * buffer and return number of bytes it was
			 * able to read.
			 */
			if((i1 = recvfrom(s, cfg.b, cfg.blen, 0, NULL, 0)) < 0) {
				PRINTE("recvfrom(%d) error for %d bytes\n",
					s, i1);
				BFREE(cfg.b);
				exit(1);
			}

			cfg.b[i1] = 0;		/* Null terminate */
			rcv_bytes += i1;

			if(!(++numb % 1000))
				printd("received %lu bytes\n",
					rcv_bytes);

			if(strncmp("ENDE", cfg.b+i1-5, 4) == 0) {
				printd("%s: finish - received %lu bytes\n\n",
					argv[0], rcv_bytes);
				rcv_bytes = 0;
			}
		}

		close(s);
		BFREE(cfg.b);
		PRINTD("sockrcv finished\n\n");
		exit(0);
	}

	/* go into an infinite loop waiting for TCP new connections */
	printd("%s: start endless loop ...\n", argv[0]);
	for(;;) {
		i2 = sizeof(isa);

		/* wait for new customers */
		if((t = accept(s,&isa,&i2)) < 0) {
			PRINTE("accept(%d) error\n", s);
			BFREE(cfg.b);
			exit(1);
		}

		/* create child process to receive data */
		pid = fork();

		/* child's thread of execution */
		if (pid == 0) {
			PRINTD("rx child (pid %d) started - parent (pid %d)\n",
				getpid(), getppid());

			close(s);

			do {
				/*
				 * recv() waits until data available.
				 * If data available, fill it into receive
				 * buffer and return number of bytes it was
				 * able to read.
				 */
				if((i1 = recv(t, cfg.b, cfg.blen, 0)) < 0) {
					PRINTE("recv(%d) error for %d bytes\n",
						t, i1);
					BFREE(cfg.b);
					exit(1);
				}

				cfg.b[i1] = 0;		/* Null terminate */
				rcv_bytes += i1;

				if(!(++numb % 1000))
					printd("received %lu bytes\n",
						rcv_bytes);

			} while(strncmp("ENDE", cfg.b+i1-5,4));

			printd("%s: finish - received %lu bytes\n\n",
				argv[0], rcv_bytes);

			rcv_bytes = 0;
			close(t);
			exit(0);
		}

		/* parent's thread of execution */
		if (pid > 0) {
			PRINTD("parent(pid %d): receive child (pid %d)\n",
				getpid(), pid);
			close(t);
			continue;
		}

		/* fork failed */
		if (pid < 0) {
			PRINTE("fork failed\n");
			close(s);
			exit(1);
		}
	}

	/* finish sockrcv */
	BFREE(cfg.b);
	PRINTD("sockrcv finished\n\n");
	exit(0);
}



/*****************************************************************************/
/*	PRIVATE FUNCTION DEFINITIONS					     */
/*****************************************************************************/

/*---------------------------------------------------------------------------*
Function:	print version
Parameters:	name: function name
Input:		none
Output:		none
Return:		none
*----------------------------------------------------------------------------*/

static void print_version(char *name)
{
	printd("%s: V"SOCKRCV_VER" (%s %s)\n",
		name, __DATE__, __TIME__);
}



/*---------------------------------------------------------------------------*
Function:	print usage
Parameters:	name: function name
Input:		none
Output:		none
Return:		none
*----------------------------------------------------------------------------*/

static void print_usage(char *name)
{
	printd("Usage: %s [-b <buf_len>] [-h] [-p <port>] [-s <src_host>]\n",
		name);
	printd("               [-t] [-u] [-v] [-V]\n");
}



/*---------------------------------------------------------------------------*
Function:	print help
Parameters:	none
Input:		none
Output:		none
Return:		none
*----------------------------------------------------------------------------*/

static void print_help(void)
{
	printd("    b: receive buffer length (default %d)\n", BUFLEN);
	printd("    h: print help\n");
	printd("    p: port number (default %d)\n", RCV_PORT & 0xffff);
	printd("    s: source host (default '%s')\n", RCV_HOST);
	printd("    t: enable timing printout\n");
	printd("    u: open UDP socket\n");
	printd("    v: enable run-time debug\n");
	printd("    V: print version only\n");
}



/*---------------------------------------------------------------------------*
Function:	get sockrcv confguration from command line
Parameters:	argc: number of command line arguments
		argv: command line parameter
		cfg: where to store parameter
Input:		command line options
Output:		none
Return:		0 => ok
		>0 => ok, exit
		<0 => error
*----------------------------------------------------------------------------*/

static int set_sockrcv_cfg(int argc, char **argv, SOCKRCV_CFG *cfg)
{
	u_char *cur;						   /* cursor */
	int i;							  /* counter */
	int opts = 0;				      /* command line option */
	int result = 0;						   /* result */

	/* check arguments */
	if(cfg == NULL) {
		PRINTE("set_sockrcv_cfg: internal error - no cfg\n");
		return(-1);
	}

	/* default configuration */
	cur = (u_char *)cfg;
	i = sizeof(SOCKRCV_CFG);
	while(i--)
		*cur++ = '\0';
	
	strncpy(cfg->shost, RCV_HOST, MAX_HN_LEN);
	cfg->port = RCV_PORT;
	cfg->blen = BUFLEN;
	cfg->b = malloc(cfg->blen + 1);

	if(cfg->b == NULL) {				     /* check buffer */
		PRINTE("set_sockrcv_cfg: internal error - no memory\n");
		return(-1);
	}

	/* get command line options */
	while(opts != EOF) {
		opts = getopts(argc, argv, "b:hp:s:tuvV");
		switch(opts) {
			case EOF: /* no more options */
				break;

			case '?': /* help or unknown option */
				if((char)optsopt == '?') {
					print_usage(argv[0]);
					print_help();
					result = 1;
				}
				else {
					PRINTE("unkown option '%c'\n",
						(char)optsopt);
					print_usage(argv[0]);
					result = -2;
				}
				break;

			case ':': /* missing argument */
				PRINTE("missing arg to option '%c'\n",
					(char)optsopt);
				print_usage(argv[0]);
				result = -2;
				break;

			case 'b': /* receive buffer length */
				free(cfg->b);
				cfg->blen = (u_long)atol(optsarg);
				cfg->b = malloc(cfg->blen + 1);
				if(cfg->b == NULL) {
					PRINTE("set_sockrcv_cfg: internal error - no memory\n");
					return(-1);
				}
				break;

			case 'h': /* print help */
				print_usage(argv[0]);
				print_help();
				result = 1;
				break;

			case 'p': /* port number */
				cfg->port = (atoi(optsarg) & 0xffff);
				break;

			case 's': /* source host */
				strncpy(cfg->shost, optsarg, MAX_HN_LEN);
				break;

			case 't': /* enable timing printout */
				cfg->time_print = 1;
				PRINTE("option 't' yet unsupported\n");
				result = -2;
				break;

			case 'u': /* open UDP socket */
				cfg->udp = 1;
				break;

			case 'v': /* enable run-time debug */
				cfg->dbg = 1;
				break;

			case 'V': /* print version only */
				print_version(argv[0]);
				result = 1;
				break;

			default: /* default */
				PRINTE("unsupported option '%c'\n",
					(char)optsopt);
				print_usage(argv[0]);
				result = -2;
				break;
		}
	}

	/* clean up in case of exit */
	if(result != 0) {
		BFREE(cfg->b);
	}

	return(result);
}


