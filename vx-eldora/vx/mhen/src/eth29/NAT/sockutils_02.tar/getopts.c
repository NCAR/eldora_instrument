/*** getopts.c ***/
/*
011111 cg initial version;
*/


/******************************************************************************
An element of argv that starts with `-' (and is not exactly "-" or "--")
is an option element. The characters of this element (aside from the initial
`-') are option characters. If getopts() is called repeatedly, it returns
successively each of the option characters from each of the option elements.

If getopts() finds another option character, it returns that character,
updating a static variable so that the next call to getopts() can resume
the scan with the following option character or argv-element.

optstring is a string containing the legitimate option characters. If such
a character is followed by a colon, the option requires an argument, so
getopts places a pointer to the following text in the same argv-element,
or the text of the following argv-element, in optsarg. If there is text
in the current  argv-element, it is returned in optsarg, otherwise optsarg
is set to zero.

The getopts() function does not support long options (option started out by
two dashes).

The getopts() function returns the option character if the option was found
successfully, `:' if there was a missing parameter for one of the options,
`?' for an unknown option character (and stores character in optsopt), or EOF
for the end of the option list.
******************************************************************************/

#include <stdio.h>
#include "getopts.h"



//#define TEST_MAIN
//#define DEBUG

#define OPT_DELIM	'-'

#ifndef printd
#define printd	printf
#endif

#ifdef DEBUG
#define PRINTD(fmt, arg...)	printd(fmt, ##arg)
#else
#define PRINTD(fmt, arg...)
#endif



char *optsarg = NULL;
int optsopt = 0;



#ifdef TEST_MAIN
int main(int argc, const char *argv[])
{
	int argc_c = argc;
	int result = 0;

	printd("main: argc %d\n", argc);
	while(argc_c) {
		printd("  [%d]: %s\n",
			argc - argc_c, argv[argc - argc_c]);
		argc_c--;
	}

	while(result != EOF) {
		result = getopts(argc, (char **)argv, "bc:d:");
		printd("  # result opt '%c'",
			(result == EOF) ? '*' : (char)result);
		if(result == '?')
			printd(" unknown option %d/%c",
				optsopt, (char)optsopt);
		if(result == ':')
			printd(" missing arg to option '%c'",
				(char)optsopt);
		if(optsarg)
			printd(" arg '%s'", optsarg);
		printd(" #\n");
	}

	return(0);
}
#endif	/* TEST_MAIN */



int getopts(int argc, char **argv, char *optstring)
{
	static int opt_c = 0;				   /* option counter */
	static char *opt_el = NULL;			   /* option element */
	static char *opt_ch = NULL;			 /* option character */
	char *opt_ch_save;			    /* save option character */
	char *cur;					    /* buffer cursor */

	PRINTD("\ngetopts: argc %d argv 0x%lx optstring %s\n",
		argc, (unsigned long)argv, optstring ? optstring : "<empty>");

next_option_element:
	/* reset global variables */
	optsarg = NULL;
	optsopt = 0;

	/*
	 * set static values and check them
	 */
	if(opt_c == 0) {
		opt_c = argc;
		opt_el = argv[1];
		opt_ch = opt_el ? opt_el : NULL;
	}

	PRINTD("  opt_c %d opt_el %s opt_ch %s\n",
		opt_c,
		opt_el ? opt_el : "<empty>",
		opt_ch ? opt_ch : "<empty>");

	/* invalid option counter */
	if(opt_c < 2) {
		PRINTD("  opt_c %d exceeded\n", opt_c);
		opt_c = 0;
		return(EOF);
	}

	/* no option element */
	if(opt_el == NULL) {
		PRINTD("  no opt_el\n");
		opt_c = 0;
		return(EOF);
	}

	/* unprocessed option element */
	if((opt_el[0] != OPT_DELIM) || (strlen(opt_el) < 2) ||
	   ((opt_el[0] == OPT_DELIM) && (opt_el[1] == OPT_DELIM))) {
		PRINTD("  unprocessed opt_el %s\n", opt_el);
		opt_c = 0;
		return(EOF);
	}

	/* skip leading delimiter */
	opt_ch++;

	/* if option element finished goto next option element */
	if(*opt_ch == 0x00) {
		PRINTD("  no opt_ch\n");
		opt_c--;
		opt_el = argv[argc - opt_c + 1];
		opt_ch = opt_el ? opt_el : NULL;
		goto next_option_element;
	}

	/* valid option character found */
	PRINTD("  valid opt_c %d opt_el %s opt_ch %c\n",
		opt_c, opt_el, *opt_ch);

	/* check if option character is indicated in optstring */
	if(!optstring) {
		PRINTD("  no optstring\n");
		return(EOF);
	}

	for(cur = optstring; *cur != 0x00; cur++)
		if(*cur == *opt_ch)
			break;

	if((*cur == 0x00) || (*cur == ':')) {
		PRINTD("  unknown opt_ch %c\n", *opt_ch);
		optsopt = (int)*opt_ch;
		return((int)'?');
	}

	/* check if option takes argument */
	opt_ch_save = opt_ch;
	cur++;
	if(*cur == ':') {
		if(*(opt_ch + 1) != 0x00) {    /* argument in current opt_el */
			optsarg = opt_ch + 1;
			PRINTD("  opt_ch %c with arg %s in same opt_el\n",
				*opt_ch, optsarg);
			opt_c--;		 /* prepare next run */
			opt_el = argv[argc - opt_c + 1];
			opt_ch = opt_el ? opt_el : NULL;
		}
		else {				  /* argument in next opt_el */
			optsarg = argv[argc - opt_c + 2];
			PRINTD("  opt_ch %c with arg %s in next opt_el\n",
				*opt_ch, optsarg ? optsarg : "<empty>");
			if(!optsarg) {
				optsopt = (int)*opt_ch_save;
				return((int)':');
			}
			opt_c -= 2;
			opt_el = argv[argc - opt_c + 1];
			opt_ch = opt_el ? opt_el : NULL;
		}
	}

	return((int)*opt_ch_save);
}


