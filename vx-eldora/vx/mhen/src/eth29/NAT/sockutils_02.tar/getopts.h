/*** getopts.h ***/
/*
011111 cg initial version;
*/


/******************************************************************************
An element of argv that starts with `-' (and is not exactly "-" or "--")
is an option element. The characters of this element (aside from the initial
`-') are option characters. If getopts() is called repeatedly, it returns
successively each of the option characters from each of the option elements.

If getopts() finds another option character, it returns that character,
updating a static variable so that the next call to getopts() can resume
the scan with the following option character or argv-element.

optstring is a string containing the legitimate option characters. If such
a character is followed by a colon, the option requires an argument, so
getopts places a pointer to the following text in the same argv-element,
or the text of the following argv-element, in optsarg. If there is text
in the current  argv-element, it is returned in optsarg, otherwise optsarg
is set to zero.

The getopts() function does not support long options (option started out by
two dashes).

The getopts() function returns the option character if the option was found
successfully, `:' if there was a missing parameter for one of the options,
`?' for an unknown option character (and stores character in optsopt), or EOF
for the end of the option list.

Refer to getopts.c for example code.
******************************************************************************/

int getopts(int argc, char **argv, char *optstring);

extern char *optsarg;
extern int optsopt;
