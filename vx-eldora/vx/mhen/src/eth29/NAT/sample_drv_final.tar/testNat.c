#include <vxWorks.h>
#include "customize.h"
#include <sys/socket.h>
#include <netinet/in.h>

int NATfd;

void n1() {


  NATfd = P_Socket(AF_INET, SOCK_DGRAM, 0);

  logMsg("socket NATfd is %d\n", NATfd);

}

void n2() {

  char* to_name = "192.168.10.11";

  int status;

  struct sockaddr_in to;

  to.sin_family = AF_INET;
  to.sin_port = 2000;
  to.sin_addr.s_addr = inet_addr(to_name);

  logMsg("s_addr is 0x%x\n", to.sin_addr.s_addr);
  taskDelay(50);

  status = P_Connect(NATfd,
		     &to,
		     sizeof(to));

  logMsg("connect status is %d\n", status);
}

void n3() {

  char* buf[1000];

  int status;

  logMsg("sending on socket %d\n", NATfd);
  taskDelay(50);

  status = P_Send(NATfd,
		  buf,
		  1000,
		  0);

  logMsg("send status is %d\n", NATfd);
}

#define START 0
#define END   0xfffff

int memTest() {
  
  int result = 0;

  unsigned long* lbegin = START + CUSTOMIZE_MODULE_ADDRESS;
  unsigned long* lend   = END   + CUSTOMIZE_MODULE_ADDRESS;

  unsigned short* sbegin = START + CUSTOMIZE_MODULE_ADDRESS;
  unsigned short* send   = END   + CUSTOMIZE_MODULE_ADDRESS;

  unsigned char* cbegin = START + CUSTOMIZE_MODULE_ADDRESS;
  unsigned char* cend   = END   + CUSTOMIZE_MODULE_ADDRESS;

  unsigned long* lptr;
  unsigned short* sptr;
  unsigned char* cptr;

  logMsg("writing longs\n");
  for (lptr = lbegin; lptr < lend; lptr++) 
    *lptr = lptr;

  logMsg("reading longs\n");
  for (lptr = lbegin; lptr < lend; lptr++) {
    unsigned long valueRead = *lptr;
    if (valueRead != lptr) {
      logMsg("long read back error at 0x%x, value read as 0x%x\n", lptr, valueRead);
      result = -1;
      return -1;
    }
  }
  
  logMsg("writing shorts\n");
  for (sptr = sbegin; sptr < send; sptr++) 
    *sptr = sptr;

  logMsg("reading shorts\n");
  for (sptr = sbegin; sptr < send; sptr++) {
    unsigned short valueRead = *sptr;
    if (valueRead != (unsigned short) sptr) {
      logMsg("short read back error at 0x%x, value read as 0x%x\n", 
	     sptr, valueRead);
      result = -1;
    }
  }
  
  logMsg("writing chars\n");
  for (cptr = cbegin; cptr < cend; cptr++) 
    *cptr = cptr;

  logMsg("reading chars\n");
  for (cptr = cbegin; cptr < cend; cptr++) {
    unsigned char valueRead = *cptr;
    if (valueRead != (unsigned char) cptr) {
      logMsg("char read back error at 0x%x, value read as 0x%x\n", cptr, valueRead);
      result = -1;
    }
  }
  
  return result;
}
