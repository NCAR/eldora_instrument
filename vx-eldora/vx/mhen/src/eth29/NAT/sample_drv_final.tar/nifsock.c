/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : nifsock.c
*
* Description : Network InterFace (NIF) routines for socket level functions
*		for intelligent slaveboards
*
* Author      : H.Laufkoetter
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
*	    Corrected known bug in com_with_slave() when initializing nifp
*		pointer, was to V_Port always (true for	MS360 only !) and
*		should be to m instead (if not MS360).
* 951219 hk Initial version for CUSTOMIZE, adapted from original nifsock.c
******************************************************************************
******************************************************************************/

//#include "natdefs.h"
#include <vxWorks.h>
#include "errno.h"
#include "mbuf.h"
#include "socket.h"
#include "neterrno.h"
#include "nif.h"
#include "hwconfig.h"

#include "customize.h"			/* CUSTOMIZE her */

extern u_char *V_Port;			/* address of module on bus */
extern u_char *V_Nif;			/* address of module's NIF field */
extern u_char V_ProtPort;		/* well known protocol family */
extern u_long V_License;		/* valid license for this hardware */
extern int sockprintfs;			/* debuf level */
extern struct mbuf localm;		/* local copy of mbuf */

extern struct mbuf *C_In;
extern struct mbuf *C_Out;

struct mbuf* C_queget(unsigned short pid);

/*--------------------------------------------------------------------------*/
FUNCTION int com_with_slave(m0, pid)	/* basic interface routine for all  */
					/* commands from the masterboard to */
					/* slaveboard			    */
/*--------------------------------------------------------------------------*/
	struct mbuf *m0;		/* transport mbuf for function params*/
	u_short pid;			/* our own process id		     */
{
	struct mbuf *m;
	register struct nifpar *nifp;
	u_short irq_mask;
	int RVal;

	nifp = mtod(m0, struct nifpar*);

	if (sockprintfs >= 3) {
		logMsg("com_with_slave: Command = %d, PID = %d\n",
				nifp->Command, nifp->PID);
		taskDelay(50);
	}

	/*
	 * Write Protocol number for communication with the slavebord
	 * to the second byte of the variable Command in the nif structure.
	 */
	nifp->Command |= (COMPROT_TCPIP << 8);

	/*
	 * Send an interrupt to the slave board and then sleep
	 * until the slaveboard answers.
	 */
	action(m0);

	CUSTOMIZE_SLEEP(UNTIL_SIGNAL_ARRIVES);

	if (sockprintfs >= 5) {
		logMsg("com_with_slave: awaken first time ");
		if (sockprintfs >= 6) {
			logMsg("(Com=%d, pid=%d, PID=%d)\n",
					nifp->Command, pid, nifp->PID);
			//			logMsg("\t&C_In=%08x, C_In=%08x, &C_Out=%08x, C_Out=%08x\n",
				//	&C_In, C_In, &C_Out, C_Out);
		} else {
			logMsg("\n");
		}
	}

	/* the answer has been enqueued by the IRQ-service routine
	 * into a common FIFO-queue for all processes using the slaveboard
	 * C_queget takes out only those elements which are for this
	 * process (pid)
	 */

	while ((m = C_queget(pid)) == 0) {

		if (sockprintfs >= 5) {
			logMsg("com_with_slave: no answer found, sleep again ");
			if (sockprintfs >= 6) {
				logMsg("(Com=%d, pid=%d, PID=%d)\n",
					nifp->Command, pid, nifp->PID);
				logMsg("\t&C_In=%08x, C_In=%08x, &C_Out=%08x, C_Out=%08x\n",
					&C_In, C_In, &C_Out, C_Out);
			} else {
				logMsg("\n");
			}
		}

		CUSTOMIZE_SLEEP(UNTIL_SIGNAL_ARRIVES);
	}

	/*
	 * having the answer in mbuf(m).
	 */
	mask_irq(&irq_mask);
	nifp = mtod(m, struct nifpar *);

	if (sockprintfs >= 5) {
		logMsg("com_with_slave: Got an answer ");
		if (sockprintfs >= 6) {
			logMsg("(Com=%d, pid=%d, PID=%d)\n",
					nifp->Command, pid, nifp->PID);
			logMsg("\t&C_In=%08x, C_In=%08x, &C_Out=%08x, C_Out=%08x\n",
					&C_In, C_In, &C_Out, C_Out);
		}  else {
			logMsg("\n");
		}
	}

	RVal = nifp->Status;		/* get the returned status */

	enab_irq(&irq_mask);

	if (RVal == ERROR) {
		errno = nifp->Errno;
	}
	put_mbuf(m);		/* return the transport buffer to the slave */
	return(RVal);
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Socket(dom, type, proto)
/*--------------------------------------------------------------------------*/
	int dom, type, proto;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();			/* get transport mbuf from slave */
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Socket: mbuf address = %08x\n", m);
	}

	/*
	 * Put socket call parameters to the network interface.
	 * setting up in local memory
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_SOCKET;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Socket.dom = dom;
	nifp->Opt.Par_Socket.type = type;
	nifp->Opt.Par_Socket.proto = proto;
	nifp->Opt.Par_Socket.uid = CUSTOMIZE_PID;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("Domain = %d, Type = %d, proto = %d, uid = %x\n",
				nifp->Opt.Par_Socket.dom,
				nifp->Opt.Par_Socket.type,
				nifp->Opt.Par_Socket.proto,
				nifp->Opt.Par_Socket.uid);
	}

#ifdef MS360
	cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
	memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Bind(sock, name, namelen)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t name;
	int namelen;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Bind: mbuf address = %08x\n", m);
	}

	/*
	 * Put bind call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_BIND;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Bind.socket = sock;
	nifp->Opt.Par_Bind.name = name;
	nifp->Opt.Par_Bind.namelen = namelen;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, name = %08x, namelen = %d\n",
				nifp->Opt.Par_Bind.socket,
				nifp->Opt.Par_Bind.name,
				nifp->Opt.Par_Bind.namelen);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}


/*--------------------------------------------------------------------------*/
FUNCTION int P_Listen(sock, backlog)
/*--------------------------------------------------------------------------*/
	int sock, backlog;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Listen: mbuf address = %08x\n", m);
	}

	/*
	 * Put listen call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_LISTEN;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Listen.socket = sock;
	nifp->Opt.Par_Listen.backlog = backlog;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, backlog = %d\n",
				nifp->Opt.Par_Listen.socket,
				nifp->Opt.Par_Listen.backlog);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Accept(sock, name, anamelen)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t name;
	int *anamelen;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Accept: mbuf address = %08x\n", m);
		logMsg("1.) socket = %d, name = %08x, anamelen = %08x\n",
			sock, name, anamelen);
	}

	/*
	 * Put accept call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_ACCEPT;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Accept.socket = sock;
	nifp->Opt.Par_Accept.name = name;
	nifp->Opt.Par_Accept.anamelen = anamelen;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, name = %08x, anamelen = %08x\n",
				nifp->Opt.Par_Accept.socket,
				nifp->Opt.Par_Accept.name,
				nifp->Opt.Par_Accept.anamelen);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Connect(sock, name, namelen)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t name;
	int namelen;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Connect: mbuf address = %08x\n", m);
	}

	/*
	 * Put connect call parameters to the network interface.
	 */
	nifp = mtod(m, struct nifpar*);
	nifp->Command = SOC_CONNECT;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Connect.socket = sock;
	nifp->Opt.Par_Connect.name = name;
	nifp->Opt.Par_Connect.namelen = namelen;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, name = %08x, namelen = %d\n",
				nifp->Opt.Par_Connect.socket,
				nifp->Opt.Par_Connect.name,
				nifp->Opt.Par_Connect.namelen);
		logMsg("address of name is 0x%x, namelen is 0x%x\n", name, namelen);
	}

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Sendto(sock, buf, len, flags, to, tolen)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t buf;
	int len, flags;
	caddr_t to;
	int tolen;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	logMsg("P_Sendto: getting an mbuf\n");
	taskDelay(50);
	m = get_mbuf();
	logMsg("P_Sendto:\n");
	taskDelay(50);
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Sendto: mbuf address = %08x\n", m);
	}

	/*
	 * Put sendto call parameters to the network interface.
	 */
	logMsg("P_Sendto: filling nifp\n");
	taskDelay(50);

	nifp = mtod(m, struct nifpar*);
	nifp->Command = SOC_SENDTO;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Sendto.socket = sock;
	nifp->Opt.Par_Sendto.buf = buf;
	nifp->Opt.Par_Sendto.len = len;
	nifp->Opt.Par_Sendto.flags = flags;
	nifp->Opt.Par_Sendto.to = to;
	nifp->Opt.Par_Sendto.tolen = tolen;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, buf = %08x, len = %d, flags = %x, to = %08x, tolen = %d\n",
				nifp->Opt.Par_Sendto.socket,
				nifp->Opt.Par_Sendto.buf,
				nifp->Opt.Par_Sendto.len,
				nifp->Opt.Par_Sendto.flags,
				nifp->Opt.Par_Sendto.to,
				nifp->Opt.Par_Sendto.tolen);
	}

	logMsg("P_Sendto: calling com_with_slave\n");
	taskDelay(50);
	return(com_with_slave(m, CUSTOMIZE_PID));
}


/*--------------------------------------------------------------------------*/
FUNCTION int P_Send(sock, buf, len, flags)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t buf;
	int len, flags;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Send: mbuf address = %08x\n", m);
	}

	/*
	 * Put send call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_SEND;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Send.socket = sock;
	nifp->Opt.Par_Send.buf = buf;
	nifp->Opt.Par_Send.len = len;
	nifp->Opt.Par_Send.flags = flags;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, buf = %08x, len = %d, flags = %x\n",
				nifp->Opt.Par_Send.socket,
				nifp->Opt.Par_Send.buf,
				nifp->Opt.Par_Send.len,
				nifp->Opt.Par_Send.flags);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Sendmsg(sock, msg, flags)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t msg;
	int flags;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Sendmsg: mbuf address = %08x\n", m);
	}

	/*
	 * Put sendmsg call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_SENDMSG;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Sendmsg.socket = sock;
	nifp->Opt.Par_Sendmsg.msg = msg;
	nifp->Opt.Par_Sendmsg.flags = flags;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, msg = %08x, flags = %x\n",
				nifp->Opt.Par_Sendmsg.socket,
				nifp->Opt.Par_Sendmsg.msg,
				nifp->Opt.Par_Sendmsg.flags);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}


/*--------------------------------------------------------------------------*/
FUNCTION int P_Recvfrom(sock, buf, len, flags, from, fromlenaddr)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t buf;
	int len, flags;
	caddr_t from;
	int *fromlenaddr;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Recvfrom: mbuf address = %08x\n", m);
	}

	/*
	 * Put Recvfrom call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_RECVFROM;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Recvfrom.socket = sock;
	nifp->Opt.Par_Recvfrom.buf = buf;
	nifp->Opt.Par_Recvfrom.len = len;
	nifp->Opt.Par_Recvfrom.flags = flags;
	nifp->Opt.Par_Recvfrom.from = from;
	nifp->Opt.Par_Recvfrom.fromlenaddr = fromlenaddr;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, buf = %08x, len = %d, flags = %x, from = %08x, fromlenaddr = %08x\n",
				nifp->Opt.Par_Recvfrom.socket,
				nifp->Opt.Par_Recvfrom.buf,
				nifp->Opt.Par_Recvfrom.len,
				nifp->Opt.Par_Recvfrom.flags,
				nifp->Opt.Par_Recvfrom.from,
				nifp->Opt.Par_Recvfrom.fromlenaddr);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Recv(sock, buf, len, flags)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t buf;
	int len, flags;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Recv: mbuf address = %08x\n", m);
	}

	/*
	 * Put recv call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_RECV;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Recv.socket = sock;
	nifp->Opt.Par_Recv.buf = buf;
	nifp->Opt.Par_Recv.len = len;
	nifp->Opt.Par_Recv.flags = flags;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, buf = %08x, len = %d, flags = %x\n",
				nifp->Opt.Par_Recv.socket,
				nifp->Opt.Par_Recv.buf,
				nifp->Opt.Par_Recv.len,
				nifp->Opt.Par_Recv.flags);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Recvmsg(sock, msg, flags)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t msg;
	int flags;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Recvmsg: mbuf address = %08x\n", m);
	}

	/*
	 * Put recvmsg call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_RECVMSG;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Recvmsg.socket = sock;
	nifp->Opt.Par_Recvmsg.msg = msg;
	nifp->Opt.Par_Recvmsg.flags = flags;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, msg = %08x, flags = %x\n",
				nifp->Opt.Par_Recvmsg.socket,
				nifp->Opt.Par_Recvmsg.msg,
				nifp->Opt.Par_Recvmsg.flags);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Shutdown(sock, how)
/*--------------------------------------------------------------------------*/
	int sock;
	int how;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Shutdown: mbuf address = %08x\n", m);
	}

	/*
	 * Put shutdown call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_SHUTDOWN;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Shutdown.socket = sock;
	nifp->Opt.Par_Shutdown.how = how;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, how = %d\n",
				nifp->Opt.Par_Shutdown.socket,
				nifp->Opt.Par_Shutdown.how);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Setsockopt(sock, level, name, val, valsize)
/*--------------------------------------------------------------------------*/
	int sock;
	int level, name;
	caddr_t val;
	int valsize;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Setsockopt: mbuf address = %08x\n", m);
	}

	/*
	 * Put setsockopt call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_SETSOCKOPT;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Setsockopt.socket = sock;
	nifp->Opt.Par_Setsockopt.level = level;
	nifp->Opt.Par_Setsockopt.name = name;
	nifp->Opt.Par_Setsockopt.val = val;
	nifp->Opt.Par_Setsockopt.valsize = valsize;

	if ((level == SOL_SOCKET) && (name == SO_DEBUG)) {
		sockprintfs = *(int *)val;
	}

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, level = %d, name = %d, val = %x, valsize = %d\n",
				nifp->Opt.Par_Setsockopt.socket,
				nifp->Opt.Par_Setsockopt.level,
				nifp->Opt.Par_Setsockopt.name,
				nifp->Opt.Par_Setsockopt.val,
				nifp->Opt.Par_Setsockopt.valsize);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Getsockopt(sock, level, name, val, avalsize)
/*--------------------------------------------------------------------------*/
	int sock;
	int level, name;
	caddr_t val;
	int *avalsize;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Getsockopt: mbuf address = %08x\n", m);
	}

	/*
	 * Put getsockopt call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_GETSOCKOPT;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Getsockopt.socket = sock;
	nifp->Opt.Par_Getsockopt.level = level;
	nifp->Opt.Par_Getsockopt.name = name;
	nifp->Opt.Par_Getsockopt.val = val;
	nifp->Opt.Par_Getsockopt.avalsize = avalsize;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, level = %d, name = %d, val = %x, avalsize = %x\n",
				nifp->Opt.Par_Getsockopt.socket,
				nifp->Opt.Par_Getsockopt.level,
				nifp->Opt.Par_Getsockopt.name,
				nifp->Opt.Par_Getsockopt.val,
				nifp->Opt.Par_Getsockopt.avalsize);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Getsockname(sock, asa, alen)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t asa;
	int *alen;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Getsockname: mbuf address = %08x\n", m);
	}

	/*
	 * Put getsockname call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_GETSOCKNAME;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Getsockname.socket = sock;
	nifp->Opt.Par_Getsockname.asa = asa;
	nifp->Opt.Par_Getsockname.alen = alen;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, asa = %08x, alen = %08x\n",
				nifp->Opt.Par_Getsockname.socket,
				nifp->Opt.Par_Getsockname.asa,
				nifp->Opt.Par_Getsockname.alen);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Getpeername(sock, asa, alen)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t asa;
	int *alen;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Getpeername: mbuf address = %08x\n", m);
	}

	/*
	 * Put getpeername call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_GETPEERNAME;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Getpeername.socket = sock;
	nifp->Opt.Par_Getpeername.asa = asa;
	nifp->Opt.Par_Getpeername.alen = alen;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, asa = %08x, alen = %08x\n",
				nifp->Opt.Par_Getpeername.socket,
				nifp->Opt.Par_Getpeername.asa,
				nifp->Opt.Par_Getpeername.alen);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Ioctl(sock, cmd, cmarg)
/*--------------------------------------------------------------------------*/
	int sock;
	u_long cmd;
	caddr_t cmarg;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Ioctl: mbuf address = %08x\n", m);
	}

	/*
	 * Put ioctl call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_IOCTL;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Ioctl.socket = sock;
	nifp->Opt.Par_Ioctl.cmd = cmd;
	nifp->Opt.Par_Ioctl.cmarg = cmarg;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, cmd = %08x, cmarg = %08x\n",
				nifp->Opt.Par_Ioctl.socket,
				nifp->Opt.Par_Ioctl.cmd,
				nifp->Opt.Par_Ioctl.cmarg);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Close(sock)
/*--------------------------------------------------------------------------*/
	int sock;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Close: mbuf address = %08x\n", m);
	}

	/*
	 * Put ioctl call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_CLOSE;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Close.socket = sock;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d\n", nifp->Opt.Par_Close.socket);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Getstatdata(sock, type, to, len)
/*--------------------------------------------------------------------------*/
	int sock;
	int type;
	char * to;
	int len;
{
	P_Getstataddr(sock, type, to, len);
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Getstataddr(sock, type, to, len)
/*--------------------------------------------------------------------------*/
	int sock;
	int type;
	char * to;
	int len;
{
	struct mbuf *m;
	register struct nifpar *nifp;
	int rval, rval_save;

	m = get_mbuf();
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_Getstataddr: mbuf address = %08x\n", m);
	}

	/*
	 * Put ioctl call parameters to the network interface.
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_GETSTATADDR;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_Getstataddr.socket = sock;
	nifp->Opt.Par_Getstataddr.type = type;

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, type = %d\n",
				nifp->Opt.Par_Getstataddr.socket, type);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	rval = com_with_slave(m, CUSTOMIZE_PID);

	if (rval != 0) {
	  //		rval &= (MAX_MPRAM -1);
		rval_save = rval;
		rval += V_Port;

		if (sockprintfs >= 4) {
			logMsg("\nP_Getstataddr/-data: GETSTAT-ADDR/-DATA: rval = %08x, to = %08x, len = %d\n",
						rval, to, len);
		}

		if (to != (char *)0) {
#ifdef MS360
                        cpy_from_ms360(V_Port,rval,to,len);
#else /* !MS360 */
                        memcpy(to,rval,len);
#endif /* MS360 */
			rval = rval_save;
		}
	}

	return(rval);
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_Getstat_at(from, to, len)
/*--------------------------------------------------------------------------*/
	char *from, *to;
	int len;
{
	from += (u_long)V_Port;

	if (sockprintfs >= 4) {
		logMsg("P_Getstat_at: from = %08x, to = %08x, len = %d\n",
			from, to, len);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,from,to,len);
#else /* !MS360 */
        memcpy(to,from,len);
#endif /* MS360 */

	return(0);
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_set_dbgopt(sock, dbg_opt, dbg_cmd)
/*--------------------------------------------------------------------------*/
	int sock;
	caddr_t dbg_opt;
	u_long *dbg_cmd;
{
	struct mbuf *m;
	register struct nifpar *nifp;

	m = get_mbuf();			/* get transport mbuf from slave */
	if (m == 0) {
		errno = ENOMEM;
		return(ERROR);
	}

	if (sockprintfs >= 3) {
		logMsg("P_set_dbgopt: mbuf address = %08x\n", m);
	}

	/*
	 * Put socket call parameters to the network interface.
	 * setting up in local memory
	 */
	nifp = (struct nifpar*)localm.m_dat;
	nifp->Command = SOC_SET_DBGOPT;
	nifp->PID = CUSTOMIZE_PID;
	nifp->Opt.Par_set_dbgopt.sock = sock;
	nifp->Opt.Par_set_dbgopt.dbg_opt = (u_char)(*dbg_opt);
	nifp->Opt.Par_set_dbgopt.dbg_cmd = (u_char)(*dbg_cmd);

	if (sockprintfs >= 3) {
		logMsg("Command = %d, PID = %d\n", nifp->Command, nifp->PID);
		logMsg("socket = %d, dbg_opt = %d, dbg_cmd = %d\n",
				nifp->Opt.Par_set_dbgopt.sock,
				nifp->Opt.Par_set_dbgopt.dbg_opt,
				nifp->Opt.Par_set_dbgopt.dbg_cmd);
	}

#ifdef MS360
        cpy_to_ms360(V_Port,localm.m_dat,m->m_dat,sizeof(struct nifpar));
#else /* !MS360 */
        memcpy(m->m_dat,localm.m_dat,sizeof(struct nifpar));
#endif /* MS360 */

	return(com_with_slave(m, CUSTOMIZE_PID));
}

/*--------------------------------------------------------------------------*/
FUNCTION int P_test_license()
/*--------------------------------------------------------------------------*/
{
	logMsg("P_test_license: License 0x%x\n", V_License);
	return (0);
}

