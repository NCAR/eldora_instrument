/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : hwconfig.h
*
* Description : Common Definitions for the all supported boards
*
* Author      : H.Laufkoetter
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
* 900808 hl Initial version
******************************************************************************
******************************************************************************/

#ifndef __HWCONFIG__
#define __HWCONFIG__

//#define MPRAM_BASE	(0x100000)	/* Base Address of Multiport Ram    */
//#define MPRAM_SIZE	(0x100000)	/* Size of Multiported Ram	    */
#define MAX_MPRAM	(0x400000)	/* maximum Multiported Ram	*/

//#define DPRBASE		(0xffffe000)
//#define MBOXADR		(0x1fffff)	/* DM 03/02/96 */
//#define BIM_ADR		(0x300000)	/* Address of Bus Interrupter Module*/
//#define NIFADR		(0x104000)	/* DM 03/02/96 */
//#define MBOX_VECT	(29)		/* AV5 */
//#define TIME_VECT	(80)		/* periodic timer vector	*/
//#define V_SDMA		(64 + 0x16)	/* user vectors start at 64	*/
//#define V_SCC1		(64 + 0x1e)	/* user vectors start at 64	*/
//#define V_SCC2		(64 + 0x1d)	/* user vectors start at 64	*/
//#define BIM_IRQ		*(UCHAR*)BIM_ADR= 0x01;

#endif /* __HWCONFIG__ */
