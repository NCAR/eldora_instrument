/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : sockstat.c
*
* Description : Definition of static variables for the socket driver
*
* Author      : H.Koerte
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
* 951219 hk Initial version for CUSTOMIZE, adapted from original sockstat.c						   *
******************************************************************************
******************************************************************************/

//#include "natdefs.h"
#include <vxWorks.h>
#include "mbuf.h"

/*----------------------------------------------------------------------*/
/*      Global Variables                                                */
/*----------------------------------------------------------------------*/
u_char *V_Port;			/* address of board on bus 		*/

u_long *V_Nif;			/* address of boards's NIF field 	*/
u_char *V_Mbox;			/* address of boards's mbox cell 	*/

u_char V_Vector;		/* IRQ vector 				*/
u_char V_Level;			/* IRQ level 				*/
u_char V_Prior;			/* IRQ priority 			*/
u_char V_ProtPort;		/* well known protocol family 		*/
u_char V_EthID[6];		/* Ethernet address of board 		*/
u_short V_BoardT;		/* M-Bus board type 			*/
u_long V_License;		/* valid license for this hardware 	*/
int sockprintfs;		/* debug level of driver		*/
struct mbuf localm;		/* local copy of mbuf			*/

struct mbuf *C_In;		/* head of the mbuf-in-queue 		*/
struct mbuf *C_Out;		/* head of the mbuf-out-queue 		*/
int error;			/* contains error codes			*/
