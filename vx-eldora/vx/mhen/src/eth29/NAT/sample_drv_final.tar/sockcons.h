/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : sockcons.h
*
* Description : Common definitions of socket constants
*
* Author      : H.Laufkoetter
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
* 900808 hl Initial version
******************************************************************************
******************************************************************************/

#ifndef	_SOCKCONST_
#define	_SOCKCONST_

#define	INIT		1
#define	SOCKET		2
#define	BIND		3
#define	LISTEN		4
#define	ACCEPT		5
#define	CONNECT		6
#define	SOCKETPAIR	7
#define	SENDTO		8
#define	SEND		9
#define	SENDMSG		10
#define	RECVFROM	11
#define	RECV		12
#define	RECVMSG		13
#define	SHUTDOWN	14
#define	SETSOCKOPT	15
#define	GETSOCKOPT	16
#define	GETSOCKNAME	17
#define	GETPEERNAME	18
#define	IOCTL		19
#define STARTDRV	20
#define PFFASTTIMO	21
#define PFSLOWTIMO	22
#define IFSLOWTIMO	23
#define CLEARPARPID	24
#define	GETSTATDATA	25
#define	GETSTATADDR	26
#define	GETSTAT_AT	27
#define CLOSE		28
#define SELECT		29
#define TEST_LICENSE	30
#define GETHOSTNAME	31
#define	TCP_SETDBGBUF	32
#define	TCP_GETDBGBUF	33
#define	SL_OPEN		34
#define	SL_INPUT	35
#define	SL_CLOSE	36
#define TEST		37
#define SS_SEVENT	38
/* the following four are ISO/OSI only */
#define GET_RTTABLE	39
#define SET_DBGOPT	40
#define ESISCONFIG	41
#define SNPACAGE	42
/* the following four are valid for ETH29/FDDI29 smart versions only */
#define SENDX		43
#define SYSREQMEM	44
#define SYSRETMEM	45

#define	STAT_MBUF	1
#define	STAT_TCP	2
#define	STAT_UDP	3
#define	STAT_IP		4
#define	STAT_ICMP	5
#define	STAT_TCB	6
#define	STAT_UDB	7
#define	STAT_IFNET	8
#define STAT_HASHSIZE	9
#define STAT_HOSTADDR	10
#define	STAT_NETADDR	11
#define	STAT_RTSTAT	12

#endif	/* _SOCKCONST_ */
