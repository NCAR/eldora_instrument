/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : isockdrv.c
*
* Description : Driver initialization sequence and ISR
*
* Author      : H.Koerte
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Corrected known bug in lan_irq() with call to nif_getACTS2H().
*	    Corrected known nug in C_queget() with missing code sequence
*		in case C_Out equals m_act.
*	    Corrected bug in C_queget() when initializing m_last: it was
*		m_last=&C_out and should have been m_last=C_Out;
*	    Rearranged cases of switch structure in lan_irq().
*	    Code clean up and inserted some comments.
* 980303 hl Fixed bug in cpy_out_m routine, taken over C_queget routine
*		from actual ISDN driver
* 951219 hk Initial version for CUSTOMIZE, adapted from isockdrv_c.c and
*		isockdrv_a.a
******************************************************************************
******************************************************************************/


#include "nif.h"
#include "neterrno.h"
#include "sockcons.h"
#include "hwconfig.h"
#include "errno.h"
#include "mbuf.h"
#include "customize.h"             /* please customize this file */
#include "param.h"

extern u_char *V_Port;          /* address of module on bus */
extern u_char *V_Nif;           /* address of module's NIF field */
extern u_char *V_Mbox;          /* address of module's mbox cell */
extern u_char V_Vector;         /* IRQ vector */
extern u_char V_Level;          /* IRQ level */
extern u_char V_Prior;          /* IRQ priority */
extern u_char V_ProtPort;       /* well known protocol family */
extern u_char V_EthID[];        /* Ethernet address of module */
extern u_short V_BoardT;        /* M-Bus board type */
extern u_long V_License;        /* valid license for this hardware */
extern int sockprintfs;         /* debuf level */

extern struct mbuf *C_In;       /* queue ptr where to add mbufs */
extern struct mbuf *C_Out;      /* queue ptr where to get mbufs out */
extern int error;

#define NIF_OFFSET      0x4000
#define MBOX_OFFSET     0xfffe0
#define RESET_OFFSET    0xffffc

interrupt void lan_irq();       /* forward decl. */
FUNCTION int C_Init();          /* hardware initialization */

/*----------------------------------------------------------------------*/
FUNCTION int ResetSlave()             /* driver initialization sequence       */
     /*----------------------------------------------------------------------*/
{
  /*
   * set up global variables,
   */

#ifdef MS360
  * (unsigned short *) (CUSTOMIZE_MODULE_ADDRESS + RESET_OFFSET) |= 0x4000;
#else /* !MS360 */
  * (long *) (CUSTOMIZE_MODULE_ADDRESS + RESET_OFFSET) = 1L;
#endif /* MS360 */

  return(OK);
}

/*----------------------------------------------------------------------*/
FUNCTION int Init()             /* driver initialization sequence       */
     /*----------------------------------------------------------------------*/
{
  u_long i1;

  initSem();
  /*
   * set up global variables,
   */
  V_Port = CUSTOMIZE_MODULE_ADDRESS;
  V_Nif  = V_Port + NIF_OFFSET;
  V_Mbox = V_Port + MBOX_OFFSET;

  logMsg("V_Port is 0x%x\n", V_Port);

  /*
   * get information
   */
  V_ProtPort = COMPROT_TCPIP;            	/* well known protocol family port number TCP/IP */
  V_License  = CUSTOMIZE_LICENSE;  	/* license number, NB: not needed for intelligent boards */
  V_Vector   = CUSTOMIZE_IRQ_VEC;   	/* IRQ vector number for bus interrupts */
  V_Level    = CUSTOMIZE_IRQ_LVL;    	/* IRQ level number for bus interrupts */
  V_Prior    = CUSTOMIZE_IRQ_PRIOR;  	/* IRQ poll priority for bus interrupt, NB: not needed for VME */
  V_BoardT   = CUSTOMIZE_BOARD_TYPE;      /* BoardType, NB: not needed for VME */

  for (i1 = 0; i1 < 6; i1++)      /* intialize Ethernet ID        */
    V_EthID[i1] = 0;

  /*
   * Initialize input and output queue
   */
  C_In = 0;
  C_Out = 0;

  /*
   * insert IRQ routine into polling table
   */
  error = CUSTOMIZE_INSERT_IRQ(V_Vector, V_Level, lan_irq);

  /*
   * initialize Slave Board
   */
  error = C_Init(); 	/* hardware initialization sequence */

  if (error) {
    /*
     * delete IRQ routine from polling table
     */
    logMsg("C_Init: error during initialization !\n");
    CUSTOMIZE_DELETE_IRQ(V_Vector, V_Prior, V_Port);
    return(-1);
  }

  return(OK);
}

/*----------------------------------------------------------------------*/
FUNCTION int C_Init()           /* hardware initialization */
     /*----------------------------------------------------------------------*/
{
  register struct mbuf *m;
  register struct nifpar *nifp;
  struct L2M_init_p initpar;
  u_long sw_sup_IEEE_adr;
  int error, i;

  sockprintfs = 6;	/* enable all debugging */

  if (V_ProtPort == COMPROT_TCPIP)
    logMsg("C_Init: driver is using well known port number COMPROT_TCPIP\n");
  else if (V_ProtPort == COMPROT_ISO)
    logMsg("C_Init: driver is using well known port number COMPROT_ISO\n");
  else if (V_ProtPort == COMPROT_TOKEN)
    logMsg("C_Init: driver is using well known port number COMPROT_TOKEN\n");
  else {
    logMsg("C_Init: driver configured for unknown port number %d\n",
	   V_ProtPort);
    logMsg("C_Init: driver is using default: well known port number COMPROT_TCPIP\n");
    V_ProtPort = COMPROT_TCPIP;
  }

  /*
   * check wether IEEE address is
   * supplied by hardware or if it
   * is configured by socket descriptor
   */
  sw_sup_IEEE_adr = 0;

  for(i=0;i<6;i++)
    {
      if (V_EthID[i] != 0)
	{
	  initpar.my_addr[i] = V_EthID[i];
	  sw_sup_IEEE_adr = 1;
	}
      else
	initpar.my_addr[i] = 0;
    }

  if (sw_sup_IEEE_adr == 0)
    logMsg("C_Init: taking IEEE address from hardware\n");
  else
    logMsg("C_Init: taking IEEE address from socket descriptor\n");

  initpar.License    = 0x00;
  initpar.vector     = 0x00;
  initpar.level      = 0x00;

  /*
   * Initialize L2 on slave board
   */
  error = L2_Init(&initpar);

  if (error != OK) {
    logMsg("C_Init: error during L2_init - errno=%x\n",error);

    /*
     * Layer 2 uses the error code 0x080d when it has been
     * initialized before by another protocol.
     */
    if (error != EACCES)
      return(error);
  }

  /*
   * read back IEEE address from slaveboard
   */
  if (sw_sup_IEEE_adr == 0) {
    logMsg("calling L2_PhysEthID\n");
    error = L2_PhysEthID(&V_EthID[0]);
    if(error != OK) {
      logMsg("C_Init: error during L2_PhysEthID - errno=%x\n",error);
      return(error);
    }
  }
  if (sw_sup_IEEE_adr == 0) {
    logMsg("calling L2_PhysEthID\n");
    error = L2_PhysEthID(&V_EthID[0]);
    if(error != OK) {
      logMsg("C_Init: error during L2_PhysEthID - errno=%x\n",error);
      return(error);
    }
  }

  logMsg ("C_Init: got EthernetID=%02x %02x %02x %02x %02x %02x\n",
	  V_EthID[0], V_EthID[1], V_EthID[2], V_EthID[3], V_EthID[4], V_EthID[5]);

  /*
   * set up Interrupt vector and level
   * for TCP/IP on slaveboard
   */
  logMsg("calling L2_AddVect\n");
  error = L2_AddVect(V_ProtPort, V_Vector, V_Level);
  if (error != OK) {
    logMsg("C_Init: error during L2_AddVect - errno=%x\n",error);
    return(error);
  }

  logMsg("C_Init: - completed OK\n",0,0,0,0,0);

  return(OK);
}

/*----------------------------------------------------------------------*/
void lan_irq(int param)         /* interrupt service routine                */
     /*----------------------------------------------------------------------*/
{
  struct mbuf *m, *m0, *m1;
  struct nifpar *nifp;
  int pid;
  u_long copy_len, data_len, len;
  u_char *dst, *src;

  logMsg("lan_irq\n", 0, 0, 0, 0, 0);

  /*
   * get mbuf from ActS2H field so that we
   * can use it directly and check
   */
  m = nif_getACTS2H ();

  logMsg("lan_irq, m 0x%x\n", m, 0, 0, 0, 0);

  if ( m == NULL)
    return;

  nifp = mtod (m, struct nifpar *);

  logMsg("nifp is 0x%x\n", nifp, 0, 0, 0, 0);

  logMsg("Command %d, Status %d\n", nifp->Command, nifp->Status, 0, 0, 0);


  /*
   * handle slaveboard interrupt
   */
  switch (nifp->Command) {

  case S_COPYIN :
    logMsg("COPYIN\n", 0, 0, 0, 0, 0);
    src = nifp->Opt.cpdat.Cpfrom;
    dst = nifp->Opt.cpdat.Cpto;
    dst = (u_char*)(((u_long)dst & (MAX_MPRAM - 1)) + V_Port);
    copy_len = nifp->Opt.cpdat.Cplen;

    logMsg("COPYIN transferring %d bytes from 0x%x to 0x%x\n", copy_len, src, dst);
    memcpy(dst, src, copy_len);
    nifp->Command = 0;    /* clear command in mbuf */

  CPYI_AGAIN:
    error = nif_setACTH2S(m, IRQ_SIGNAL);
    if (error) {
      nif_wait();
      goto CPYI_AGAIN;
    }
    break;

  case S_COPYOUT:
    logMsg("COPYOUT\n", 0, 0, 0, 0, 0, 0);
    src = nifp->Opt.cpdat.Cpfrom;
    src = (u_char*)(((u_long)src & (MAX_MPRAM - 1)) + V_Port);
    dst = nifp->Opt.cpdat.Cpto;
    copy_len = nifp->Opt.cpdat.Cplen;
    memcpy(dst, src, copy_len);
    nifp->Command = 0;    /* clear command in mbuf */

  CPYO_AGAIN:
    error = nif_setACTH2S(m, IRQ_SIGNAL);
    if (error) {
      nif_wait();
      goto CPYO_AGAIN;
    }
    break;

  case S_COPYOUT_M :
    logMsg("COPYOUT_M\n", 0, 0, 0, 0, 0);
    m0  = (struct mbuf *)nifp->Opt.cpdat.Cpfrom;
    dst = nifp->Opt.cpdat.Cpto;
    data_len = nifp->Opt.cpdat.Cplen;
    len = 0;

    do {
      m1 = (struct mbuf*)(((u_long)m0 & (MAX_MPRAM - 1)) + V_Port);
      src = (u_char *)m1 + m1->m_off;
      copy_len = MIN(m1->m_len, data_len);
      memcpy(dst, src, copy_len);
      data_len -= copy_len;		/* NAT980303hl */
      dst += copy_len;
      len += copy_len;
      m0 = m1->m_next;
    } while(m0 && data_len > 0);
    nifp->Command = 0;    /* clear command in mbuf */
    nifp->Opt.cpdat.Cplen = len; /* put back copied length */

  CPYOM_AGAIN:
    error = nif_setACTH2S(m, IRQ_SIGNAL);
    if (error) {
      nif_wait();
      goto CPYOM_AGAIN;
    }
    break;

  case L2_RCV :
  case S_SELWAKEUP :
    logMsg("L2_RCV\n",0,0,0,0,0);
    /*
     * by default unused calls unless somebody
     * wants to implement a raw interface or the
     * UNIX select() call
     */
    break;

  default :
    /*
     * response from slave to previous
     * user command, so insert in driver
     * queue
     */

    logMsg("lan_irq: default, m:0x%x, nifp%0x\n", m, nifp,0,0,0);
    pid = nifp->PID;
    m->m_next = 0;
    if (C_Out == 0)
      C_Out = m;
    else
      C_In->m_next = m;
    C_In = m;

    /*
     * wake sleeping process
     */
    if (CUSTOMIZE_SIGNAL_PROCESS(pid, CUSTOMIZE_SIGWAKE) < 0)
      logMsg("lan_irq: wakup of process %d failed, errno 0x%x\n", pid, errno,0,0,0);

    break;
  }
}

/*----------------------------------------------------------------------*/
FUNCTION int C_Term()       /* C-part of socket driver terminate routine*/
     /*----------------------------------------------------------------------*/
{

  /*
   * Stop protocol layer 2
   */
  L2_Stop();

  return(OK); /* anyhow...                        */
}

/*----------------------------------------------------------------------*/
FUNCTION struct mbuf *C_queget(u_short pid)
     /*----------------------------------------------------------------------*/
{
  u_long irq_mask;
  struct nifpar *nifp;
  struct mbuf *m_act;
  struct mbuf *m_last;

  mask_irq(&irq_mask);


  /*
   * process queue by searching for a queued mbuf for the requested
   * PID, if found one return it's address and release memory, 0 else.
   *
   * The queue looks like this:
   *
   *               m n         m n-1          m 2           m 1
   *            |------|      |------|      |------|      |------|
   * C_In --> 0 |  0   | <--- |&(m n)| .... |&(m 3)| <--- |&(m 2)| <-- C_Out
   *            |------|      |------|      |------|      |------|
   *            |  .   |      |  .   |      |  .   |      |  .   |
   *            |  .   |      |  .   |      |  .   |      |  .   |
   *            |  .   |      |  .   |      |  .   |      |  .   |
   *            |------|      |------|      |------|      |------|
   *         12 |      |      |      |      |      |      |      | Command
   *            |------|      |------|      |------|      |------|
   *         16 |      |      |      |      |      |      |      | Status
   *            |------|      |------|      |------|      |------|
   *         20 |      |      |      |      |      |      |      | PID
   *            |------|      |------|      |------|      |------|
   *            |  .   |      |  .   |      |  .   |      |  .   |
   *            |  .   |      |  .   |      |  .   |      |  .   |
   *            |  .   |      |  .   |      |  .   |      |  .   |
   *            |------|      |------|      |------|      |------|
   */
  if((m_act = C_Out) == 0) {
    enab_irq(&irq_mask);
    return(NULL);		/* noting in queue */
  }
  m_last =  (struct mbuf *)C_Out;

  do {
    nifp = (struct nifpar *) mtod(m_act, struct nifpar*);
    if(nifp->PID == pid) {
      if(m_act == C_In)	/* it is the last element */
	C_In = m_last;

      m_last->m_next = m_act->m_next;

      if(C_Out == m_act)
	C_Out = m_act->m_next;

      if(C_Out == 0)
	C_In = 0;

      enab_irq(&irq_mask);
      return(m_act);
    }
    else {
      m_last = m_act;
      m_act = m_act->m_next;
    }
  } while (m_act);

  enab_irq(&irq_mask);
  return (0);			/* no mbuf for this PID found */
}

/*--------------------------------------------------------------------------*/
int L2_SetDebug()
     /*--------------------------------------------------------------------------*/
{
  register struct mbuf *m;
  register struct nifpar *nifp;
  int error, i;

  m = get_mbuf();
  if (m == 0) {
    logMsg("cant get mbuf in L2_SetDebug\n");
    return -1;
  }

  /*
   * set up L2_init command to slaveboard
   */

  nifp = mtod(m, struct nifpar*);
  nifp->Command = L2_DEBUG;
  nifp->Status = 0;
  nifp->PID = CUSTOMIZE_PID;
  nifp->Opt.debuglevel = 5;

  logMsg("setting debug level\n");
  action(m);				/* carry out L2_init command */

  return 0;
}


