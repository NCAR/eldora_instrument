/*****************************************************************************
******************************************************************************
*                                                                            *
*     NNNNNN         N                A             TTTTTTT TTTTTTTTTT       *
*     N NNNNN        N               AAA                  T TTTTT            *
*     NN NNNNN       N              AAAAA                 T TTTTT            *
*     N N NNNNN      N             A AAAAA                T TTTTT            *
*     N  N NNNNN     N            A A AAAAA               T TTTTT            *
*     N   N NNNNN    N           A   A AAAAA              T TTTTT            *
*     N    N NNNNN   N          A     A AAAAA             T TTTTT            *
*     N     N NNNNN  N         AAAAAAAAA AAAAA            T TTTTT            *
*     N      N NNNNN N        A         A AAAAA           T TTTTT            *
*     N       N NNNNNN       A           A AAAAA          T TTTTT            *
*     N        N NNNNN  OO  A             A AAAAA  OO     T TTTTT     OO     *
*                       OO                         OO                 OO     *
*                                                                            *
*     Gesellschaft fuer Netzwerk- und Automatisierungstechnologie m.b.H      *
*        Kamillenweg 22, D-53757 Sankt Augustin, Tel.: ++49-2241/3989-0      *
*                                                                            *
******************************************************************************
******************************************************************************
*
* Module      : nif_c.c
*
* Description : Masterboard Network Interface Routines
*
* Author      : H.Koerte
*
******************************************************************************
******************************************************************************
*
*                    Copyright (c) by N.A.T. GmbH
*
*       All rights reserved. Copying, compilation, modification,
*       distribution or any other use whatsoever of this material
*       is strictly prohibited except in accordance with a Software
*       License Agreement with N.A.T. GmbH.
*
******************************************************************************
******************************************************************************
*
* $ProjectRevision$
* $Source$
* $State$
* $Revision$ $Name$
* $Date$
* $Locker$
*
* Module's revision history:
* ==========================
*
* --------- $Log$
* 030327 hk Added NAT header.
*	    Corrected known bug in action(): nif_setACTH2S() was called
*		with wrong parameter!
*	    Corrected known bug in nif_getActS2H() with passed parameter.
*		Instead of modifying passed parameter nif_getActS2H() now
*		returns a valid mbuf or NULL else.
* 961219 hk Initial version for CUSTOMIZE, adapted from nif_a.a
******************************************************************************
******************************************************************************/

//#include "natdefs.h"
#include <vxWorks.h>
#include "nif.h"
#include "mbuf.h"
#include "hwconfig.h"
#include "customize.h"			/* CUSTOMIZE here */

#define MAX_WAIT 100

extern u_char *V_Nif;
extern u_char *V_Port;			/* address of module on bus */
extern u_char *V_Mbox;			/* address of module's mbox cell */


/*-------------------------------------------------------------------------*/
FUNCTION static void no_op()		     /* does what is ought to do   */
/*-------------------------------------------------------------------------*/
{
}

/*--------------------------------------------------------------------------*/
FUNCTION void nif_wait()
/*--------------------------------------------------------------------------*/
{
	u_long i1;

	for (i1 = 0; i1 < 1000; i1++)
		 no_op();
}

/*--------------------------------------------------------------------------*/
FUNCTION struct mbuf *get_mbuf()
/*--------------------------------------------------------------------------*/
{
	register struct ls_softc *ls;
	register u_long i1;
	register struct mbuf *m;
	u_short irq_mask;

	i1 = 0;
	mask_irq(&irq_mask);

	for(;;) {
		nif_mget(&m);
		if (m) {
		  if (m->m_off != 0xc) {
		    logMsg("get_mbuf: bad mbuf offset for m:0x%x, m_off:%d, m_len:%d\n",
			   m, m->m_off, m->m_len, 0, 0);
		}
			enab_irq(&irq_mask);
			return (m);
		} else {
			if (i1 == MAX_WAIT) {
					enab_irq(&irq_mask);
					return((struct mbuf *)0);
			}
			nif_wait();
			i1++;
		}
	}
}

/*--------------------------------------------------------------------------*/
FUNCTION char *get_page()
/*--------------------------------------------------------------------------*/
{
	register u_long i1;
	register u_char *page;
	u_short irq_mask;

	i1 = 0;
	mask_irq(&irq_mask);

	for(;;) {
		nif_pget(page);
		if (page) {
			enab_irq(&irq_mask);
			return (page);
		} else {
			if (i1 == MAX_WAIT) {
					enab_irq(&irq_mask);
					return((u_char*)0);
			}
			nif_wait();
			i1++;
		}
	}
}

/*--------------------------------------------------------------------------*/
FUNCTION int put_mbuf(m)
/*--------------------------------------------------------------------------*/
	register struct mbuf *m;
{
	register u_long i1;
	u_short irq_mask;
	u_long error;

	i1 = 0;
	error = 0;

	mask_irq(&irq_mask);

	for(;;) {
		error = nif_mput(m);
		if (error == 0) {
			enab_irq(&irq_mask);
			return(error);
		} else {
			if (i1 == MAX_WAIT) {
					enab_irq(&irq_mask);
					return(error);
			}
			nif_wait();
			i1++;
		}
	}
}

/*--------------------------------------------------------------------------*/
FUNCTION int put_page(page)
/*--------------------------------------------------------------------------*/
	register char *page;
{
	register u_long i1;
	u_short irq_mask;
	u_long error;

	i1 = 0;
	error = 0;

	mask_irq(&irq_mask);

	for(;;) {
		error = nif_pput(page);
		if (error == 0) {
			enab_irq(&irq_mask);
			return (error);
		} else {
			if (i1 == MAX_WAIT) {
					enab_irq(&irq_mask);
					return(error);
			}
			nif_wait();
			i1++;
		}
	}
}

/*--------------------------------------------------------------------------*/
FUNCTION int action(m)
/*--------------------------------------------------------------------------*/
	register struct mbuf *m;
{
	register u_long i1;
	u_short irq_mask;
	u_long error;

	i1 = 0;
	error = 0;

	mask_irq(&irq_mask);

	for(;;) {
		error = nif_setACTH2S(m, IRQ_ActH2S);
		if (error == 0) {
			enab_irq(&irq_mask);
			return(0);
		} else {
			if (i1 == MAX_WAIT) {
					enab_irq(&irq_mask);
					return(-1);
			}
			nif_wait();
			i1++;
		}
	}
}

/*--------------------------------------------------------------------------*/
FUNCTION int nif_mget(mp)
/*--------------------------------------------------------------------------*/
	struct mbuf** mp;
{
	NIF *nif;
	struct mbuf* m;

	nif = (NIF *)V_Nif;
	m = nif->mget;
	logMsg("nif_mget, m is 0x%x\n", m, 0, 0, 0, 0);

	if (m) {
		nif->mget = (struct mbuf *)0;
		*mp = (struct mbuf*)(((u_long)m & 0xfffff)  + V_Port);
		logMsg("nif_mget, m adjusted is 0x%x\n", *mp, 0, 0, 0, 0);
		if (test_mbox())
			return(-1);
		do_mbox(IRQ_MGET);
		return(0);
	}
	return(-1);
}

/*--------------------------------------------------------------------------*/
FUNCTION int nif_mput(m)
/*--------------------------------------------------------------------------*/
	struct mbuf *m;
{
	NIF *nif;

	nif = (NIF *)V_Nif;

	if (nif->mput)
		return(-1);

	if (test_mbox())
		return(-1);

	nif->mput = m;
	do_mbox(IRQ_MPUT);

	return(0);
}

/*--------------------------------------------------------------------------*/
FUNCTION int nif_pget(p)
/*--------------------------------------------------------------------------*/
        char *p;
{
        NIF *nif;

        nif = (NIF *)V_Nif;
        p = nif->pget;

        if (p) {
                nif->pget = (char *)0;
		p = (char *)(((u_long)p & 0xfffff) + V_Port);
                if (test_mbox())
                        return(-1);
                do_mbox(IRQ_PGET);
                return(0);
        }
        return(-1);
}

/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
FUNCTION int nif_pput(p)
/*--------------------------------------------------------------------------*/
	char *p;
{
	NIF *nif;

	nif = (NIF *)V_Nif;

	if (nif->pput)
		return(-1);

	if (test_mbox())
		return(-1);

	nif->pput = p;

	do_mbox(IRQ_PPUT);

	return(0);
}

/*--------------------------------------------------------------------------*/
FUNCTION struct mbuf *nif_getACTS2H()
/*--------------------------------------------------------------------------*/
{
	struct mbuf *m;
	NIF *nif;

	nif = (NIF *)V_Nif;
	m = nif->ActS2H;
logMsg("in nif_getACTS2H, m is 0x%x\n", m,0,0,0,0);
	if (m) {
		nif->ActS2H = (struct mbuf *)0;
		m = (struct mbuf*)(((u_long)m & 0xfffff) + V_Port);
		logMsg("in nif_getACTS2H, adjusted m is 0x%x\n", m,0,0,0,0);

		if (m->m_off != 0xc) {
		  logMsg("in nif_getACTS2H, returned m->m_off wrong (0x%x)\n",
			 m->m_off, 0,0,0,0);
		}
		logMsg("returning from nif_getACTS2H\n",0,0,0,0,0);
		return(m);
	}
	logMsg("error return from nif_getACTS2H\n",0,0,0,0,0);
	return((struct mbuf *)NULL);
}

/*--------------------------------------------------------------------------*/
FUNCTION int nif_setACTH2S(m, irq_code)
/*--------------------------------------------------------------------------*/
	struct mbuf *m;
	u_char irq_code;
{
	NIF *nif;

	nif = (NIF *)V_Nif;
	if (m) {
		if (nif->ActH2S)
			return(-1);
		if (test_mbox())
			return(-1);
		nif->ActH2S = ((long)m & 0xfffff) + 0x300000;
		do_mbox(irq_code);
		return(0);
	}
	return(-1);
}

/*--------------------------------------------------------------------------*/
FUNCTION int test_mbox()
/*--------------------------------------------------------------------------*/
{
	if (*V_Mbox)
		return(-1);
	return(0);
}

/*--------------------------------------------------------------------------*/
FUNCTION int do_mbox(irq_code)
/*--------------------------------------------------------------------------*/
	u_char irq_code;
{
	*V_Mbox = irq_code;
	return(0);
}

